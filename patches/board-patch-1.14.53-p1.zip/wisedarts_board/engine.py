"""
The board engine: runs the detection loop, fuses the cameras, and keeps the
the reference board-shaped board state (status / numThrows / throws[]).

A throw is only *committed* after it has been seen in the same board-space spot
for `settle_frames` consecutive frames — that rejection of flicker is what makes
a classic-CV detector usable. Darts already stuck in the board keep showing up
as "changed" every frame, which is exactly how we know how many are on the board
and when the board has been cleared (a takeout).

State transitions emitted to listeners mirror the real board:
    running off                       -> "Stopped"
    no cameras connected              -> "Offline"
    a hand/large motion while darts up -> "Takeout in progress"
    board cleared after darts          -> "Takeout"  (numThrows -> 0)
    otherwise                          -> "Throw"
"""

from __future__ import annotations

import math
import os
import threading
import time
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field

import numpy as np

from . import geometry as geo
from . import tipnet
from .cameras import CameraHub
from .config_store import ConfigStore
from .detection import CamObservation, CameraDetector, DartCandidate


def _median(vals: list[float]) -> float:
    s = sorted(vals)
    n = len(s)
    m = n // 2
    return s[m] if n % 2 else 0.5 * (s[m - 1] + s[m])


def _fuse(pts: list[tuple[int, float, float]]) -> tuple[float, float]:
    """Fuse per-camera board-mm estimates: collapse each camera to one point
    (mean of its candidates), then take the component-wise median across cameras
    so a single off camera can't pull the result over a boundary."""
    by_cam: dict[int, list[tuple[float, float]]] = {}
    for cam, x, y in pts:
        by_cam.setdefault(cam, []).append((x, y))
    xs, ys = [], []
    for ps in by_cam.values():
        xs.append(sum(p[0] for p in ps) / len(ps))
        ys.append(sum(p[1] for p in ps) / len(ps))
    return _median(xs), _median(ys)


# Fusion strategy for multi-camera estimates (WD_FUSE): "trim" (default — drop
# the outlier camera, then Jacobian-weighted least squares on the rest; the
# outlier is usually the steep-oblique view whose pixel noise blows up in mm),
# "wls" (weight all cameras), "median" (component-wise median, the old default).
# Measured on the replay gate: trim 427/467 (91.4%) vs median 423 (90.6%) on
# held-out val, 3266 vs 3245 on the full 3595 — the boundary/wire calls are
# where the outlier camera was dragging the fused tip across a line.
FUSE_MODE = os.environ.get("WD_FUSE", "trim")


def _homography_jacobian(H: np.ndarray, u: float, v: float) -> np.ndarray | None:
    """d(board_mm)/d(image_px) of the image->board homography at (u, v). Returns
    None on the degenerate point where the homogeneous coordinate vanishes (the
    projective line at infinity), rather than emitting inf/NaN into the fusion."""
    p = H @ np.array([u, v, 1.0])
    d = p[2]
    if abs(d) < 1e-9:
        return None
    return np.array([
        [(H[0, 0] * d - H[2, 0] * p[0]) / d ** 2, (H[0, 1] * d - H[2, 1] * p[0]) / d ** 2],
        [(H[1, 0] * d - H[2, 0] * p[1]) / d ** 2, (H[1, 1] * d - H[2, 1] * p[1]) / d ** 2],
    ])


@dataclass
class CommittedDart:
    x_mm: float
    y_mm: float
    hit: geo.Hit
    cams: int
    # per-camera evidence at commit time: cam -> (window_patch, x, y). "Still on
    # the board" is judged against the dart's OWN look, not a global reference —
    # immune to poisoned references and to new darts landing at old spots.
    patches: dict = field(default_factory=dict)
    # set when the dart stops looking like its own patch on EVERY camera; after
    # 12 s of that, its reference-based presence vote no longer blocks takeout
    suspect_since: float | None = None
    t_commit: float = 0.0     # when this dart was committed (bounce-out window)
    t_land: float = 0.0       # FIRST commit time — never refreshed by moves; the
                              # dup guard's dt uses this (flag 132113: a nudge
                              # refreshed t_commit, dt=0 re-armed the settling
                              # refractory 4s after landing and ate a real twin)
    ev_t: float = 0.0         # when its event first hit the pool (throw ORDER)
    commit_tick: int = 0      # engine tick at commit (settling refractory)
    bounced: bool = False     # fell out after landing -> scored as a Miss
    off_board: bool = False   # committed off the scoring area (M-dart, scores 0).
                              # Like a bounce-out, it must NEVER hold takeout: its
                              # surround blob (a bounce mark / scuff) can persist
                              # forever, and re-verifying it every tick wedged the
                              # board (the reference engine never adds an off-board blob
                              # into its takeout model either).
    # evidence over time: [(tick, votes, like, n_patches), ...] sampled every
    # takeout-check tick — a REAL dart's votes/like hold, a PHANTOM's fade. The
    # decisive phantom-vs-real signal; surfaced in the "Flag misread" capture.
    ev_hist: list = field(default_factory=list)
    # this arrival's OFF-FOOTPRINT heatmap mass per camera (changed pixels on
    # previously-empty board, ::2 subsample) — the turn's self-calibrating
    # "one dart's worth" reference for the vibration-guard mass override.
    arrival_mass: dict = field(default_factory=dict)


class BoardEngine:
    def __init__(self, hub: CameraHub, store: ConfigStore, on_change=None):
        self.hub = hub
        self.store = store
        self.on_change = on_change  # callable(state_dict) -> None

        self.running = False
        self.status = "Stopped"
        self.event = ""
        self._darts: list[CommittedDart] = []
        self._clear_streak = 0
        self._tscale = 1                 # fps-aware frame-count scale (set each loop)

        self.detectors = {c.index: CameraDetector(c.index, store.cfg.tuning) for c in hub.cameras}
        self.last_obs: dict[int, CamObservation] = {}

        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._last_emit_sig = None
        self._last_active = 0.0   # last time something happened (motion / a dart)
        self._last_commit = 0.0   # last time a dart committed (for the DART vision state)
        self._last_takeout = 0.0  # last time a takeout fired (for the TAKEOUT vision state)
        self._stable_streak = 0   # consecutive still (no-motion) frames (vision state)
        # Event pool: (t, DartCandidate) from per-camera frozen events, waiting for
        # cross-camera agreement (cameras settle independently within ~a second).
        self._pool: list[tuple[float, DartCandidate]] = []
        self._gone_streak = 0     # consecutive still ticks with all committed darts gone
        self._last_activity = time.time()   # last motion/event — stillness watchdog
        self._gone_debug: dict = {}
        self._detect_pool = None         # last takeout-check votes (/api/health)
        self._rebaseline_pending = False    # takeout done, reference refresh queued
        self.calibrating = False   # server sets during auto-cal: status override
        self._rebase_streak = 0             # consecutive hand-free still ticks
        self._last_hand = 0.0               # last hand near the board (bounce-out veto)
        self._motion_run = 0                # consecutive motion ticks (hand vs falling dart)
        self._hint_queue: deque = deque(maxlen=12)   # (t, x_mm, y_mm) empty-event blob hints
        self._bounce_pool: deque = deque(maxlen=24)  # (t, cam, peak, x, y, hit, score) bounce-diag hits
        # DECISION LOG: ring buffer of engine verdicts (commits, takeouts, what
        # blocked a takeout and why, guard decisions). Survives until restart and
        # is exposed in /api/health — a manual Reset click no longer destroys the
        # evidence of why takeout hadn't fired.
        self._decision_log: deque = deque(maxlen=100)
        self._last_block_sig = None
        self._tick_n = 0                    # engine tick counter (halo coincidence)
        self._last_commit_tick = -10
        self._rescue_tried: dict = {}       # spots already given a guided second look
        # LINE-ONLY shaft votes (WD_SHAFTVOTE): cam -> (t, board line) from
        # no-tip dart events — an occluded-tip camera's Election ballot.
        self._shaft_lines: dict = {}
        self._cam_open_seen: dict = {}      # cam -> open_t (arms detector warmup)
        # classic per-dart snapshots: one row per committed dart, one cell
        # per camera, FROZEN at commit time — the dart's isolated evidence (raw
        # board crop + its movement diff + the tip position). Powers the vision
        # "Per-dart" grid; cleared when a new turn's first dart lands.
        self.dart_snaps: list[dict] = []
        # EXPERIMENTS: opt-in candidate fixes the user toggles LIVE from the
        # monitor (all default OFF = the proven-safe behaviour). Each dropped
        # real darts on the recorded replay gate, so they ship as user-controlled
        # A/B switches, not defaults. Read at runtime in the commit / takeout paths.
        # Per-throw reference (the doubles fix) + fast takeout are now the default
        # behaviour (user-validated live). Each keeps an env kill-switch for safety
        # but is otherwise always on; the monitor A/B toggles were removed.
        for det in self.detectors.values():
            det._turn_ref_on = os.environ.get("WD_TURNREF", "1") == "1"
        self._like_dead_since = None   # fast-takeout: when like died board-wide

    # -- lifecycle -------------------------------------------------------------
    def start_loop(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="engine", daemon=True)
        self._thread.start()

    def stop_loop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=2.0)

    # -- control (the PUT/POST endpoints) --------------------------------------
    def start_detection(self) -> None:
        with self._lock:
            self.running = True
            self._reset_locked(capture_ref=True)
        self._emit(force=True)

    def stop_detection(self) -> None:
        with self._lock:
            self.running = False
            self.status = "Stopped"
        self._emit(force=True)

    def _log(self, kind: str, **detail) -> None:
        self._decision_log.append({"t": time.strftime("%H:%M:%S"), "e": kind, **detail})

    def reset(self) -> None:
        # Clear the scored darts but DON'T re-snapshot the reference here: Reset is
        # usually pressed with the darts still in the board, so capturing now would
        # poison the empty-board reference with darts — then pulling them never
        # reads as "clear", the reference never re-baselines, and old dart ghosts
        # block new throws (you'd have to Stop/Start). Keeping the existing clean
        # empty reference lets the normal takeout path re-baseline once the board
        # actually clears.
        with self._lock:
            # the user clicking Reset IS the evidence that auto-takeout failed —
            # freeze the last takeout-check verdict alongside it
            self._log("manual-reset", why=self._gone_debug)
            self._reset_locked(capture_ref=False)
            self.status = "Throw"
        self._emit(force=True)

    def recapture_reference(self) -> None:
        """Re-grab the empty-board reference on every camera (after a camera was
        switched/reconfigured, the old reference no longer matches)."""
        with self._lock:
            self._reset_locked(capture_ref=True)
        self._emit(force=True)

    def _reset_locked(self, capture_ref: bool) -> None:
        self._darts.clear()
        self._pool.clear()
        self._shaft_lines.clear()
        self._clear_streak = 0
        for det in self.detectors.values():
            det.clear_turn_ref()
        if capture_ref:
            for c in self.hub.cameras:
                self.detectors[c.index].set_reference(c.latest())

    # -- detection loop --------------------------------------------------------
    def _run(self) -> None:
        FAST, SLOW = 1.0 / 30.0, 1.0 / 8.0   # the reference board-rate while throwing, idle when
                                             # nothing is happening (the active burst is
                                             # brief, so the higher rate barely costs CPU;
                                             # the event pipeline runs the CNN once per
                                             # DART, so ticks themselves are cheap)
        while not self._stop.is_set():
            t0 = time.time()
            try:
                self._tick()
            except Exception as e:  # never let one bad frame kill the loop
                self.event = f"error: {e}"
            # Adaptive rate — the big lever for weak PCs: run FAST only while something
            # is actually happening (a hand/dart moved recently), and idle at 4 fps
            # otherwise. We deliberately do NOT stay FAST just because darts are sitting
            # on the board between throws — that paid the full per-tick cost (motion +
            # CNN + takeout check on 3 cameras) continuously and was starving the loop
            # (~4 fps live). A landing dart trips the cheap frame-to-frame diff at 4 fps
            # and ramps us straight back to FAST for the settle.
            active = (time.time() - self._last_active) < 2.5
            target_dt = FAST if active else SLOW
            dt = time.time() - t0
            if dt < target_dt:
                time.sleep(target_dt - dt)

    def _tick(self) -> None:
        if not self.hub.any_connected():
            if self.status != "Offline":
                with self._lock:
                    self.status = "Offline"
                self._emit(force=True)
            return

        if not self.running:
            self._emit()
            return

        tuning = self.store.cfg.tuning
        frames = {cam.index: cam.latest() for cam in self.hub.cameras}
        now = time.time()
        # FPS-AWARE TIMING: settle_frames / clear_frames are FRAME counts tuned at
        # ~15 fps. At a higher capture rate they fire in a fraction of the
        # wall-clock time — a dart read before it settles, or takeout firing
        # before the last dart registers (the 30 fps miss / premature-takeout
        # flags). Scale by the measured capture rate so the timing is constant in
        # REAL time at any fps. Replay mock cams expose no .fps -> scale 1, so the
        # accuracy gate is unaffected.
        _fpss = sorted(c.fps for c in self.hub.cameras
                       if getattr(c, "connected", False) and getattr(c, "fps", 0) > 1)
        self._tscale = max(1, int(round((_fpss[len(_fpss) // 2] if _fpss else 15.0) / 15.0)))
        for _det in self.detectors.values():
            _det._tscale = self._tscale
        # (RE)OPEN WARMUP (reference StartupWaitFrames parity): the frozen-driver
        # watchdog reopens a device mid-game, after which it re-hunts exposure —
        # measured as motion it can fire a phantom event or freeze a mid-ramp
        # Before. Detect the reopen via open_t and hold that camera's event
        # machine idle briefly. Live-only by construction: replays never reopen.
        if os.environ.get("WD_WARMUP", "1") == "1":
            for cam in self.hub.cameras:
                ot = getattr(cam, "open_t", 0.0)
                prev = self._cam_open_seen.get(cam.index)
                if prev is None:
                    self._cam_open_seen[cam.index] = ot
                elif ot != prev:
                    self._cam_open_seen[cam.index] = ot
                    det = self.detectors.get(cam.index)
                    if det is not None and hasattr(det, "begin_warmup"):
                        det.begin_warmup()
                        self._log("cam-warmup", cam=cam.index)
        event_cands: list[DartCandidate] = []
        hand_done = False
        motion_votes = 0
        cleared_votes = 0

        # the three per-camera detects are independent and OpenCV/numpy release
        # the GIL — running them serially bound the tick rate to ~half the
        # camera rate. Each detector object is touched only by its own future.
        if os.environ.get("WD_PAR_DETECT", "1") == "1" and len(self.hub.cameras) > 1:
            if self._detect_pool is None:
                self._detect_pool = ThreadPoolExecutor(max_workers=3)
            futs = [(cam, self._detect_pool.submit(
                        self.detectors[cam.index].detect, frames[cam.index],
                        self.store.cfg.calibrations[cam.index]))
                    for cam in self.hub.cameras]
            obs_list = [(cam, f.result()) for cam, f in futs]
        else:
            obs_list = [(cam, self.detectors[cam.index].detect(
                            frames[cam.index], self.store.cfg.calibrations[cam.index]))
                        for cam in self.hub.cameras]
        for cam, obs in obs_list:
            self.last_obs[cam.index] = obs
            event_cands.extend(obs.candidates)
            if obs.motion:
                motion_votes += 1
            if obs.cleared:
                cleared_votes += 1
            if obs.hand_event:
                hand_done = True
            if getattr(obs, "shaft_line", None) is not None:
                self._shaft_lines[cam.index] = (now, obs.shaft_line)
            elif getattr(obs, "event_done", False):
                # a completed event that minted NO ballot (tips seen, hand, or
                # noise) means the board state that produced any earlier line
                # from this camera is gone — drop the stale ballot immediately.
                self._shaft_lines.pop(cam.index, None)
            if getattr(obs, "event_done", False) and not obs.candidates:
                # DIAGNOSTIC (2026-07-22 M11 triple: two darts landed with NO
                # trace anywhere): distinguishes "event froze but filters ate
                # every candidate" (this logs) from "the diff never tripped
                # an event at all" (nothing logs).
                bd = getattr(obs, "bounce_diag", None)
                if bd is not None:
                    self._log("bounce-diag", cam=cam.index, peak=bd.get("peak_changed"),
                              hits=bd.get("hits"))
                    for h in (bd.get("hits") or []):
                        self._bounce_pool.append((now, cam.index, bd.get("peak_changed", 0),
                                                  h.get("x"), h.get("y"), h.get("hit"),
                                                  h.get("score", 0.0)))
                hint = getattr(obs, "reject_hint", None)
                if hint is not None:
                    # persist (5s TTL): the board is usually still MOVING on the
                    # tick a hint arrives (the next throw), so a per-tick hint
                    # died before the rescue could run — recorded live 2026-07-22
                    # (hint:True x7, zero rescues)
                    self._hint_queue.append((now, float(hint[0]), float(hint[1])))
                self._log("event-empty", cam=cam.index, hint=bool(hint))

        n_cams = len(self.hub.cameras)
        # Big motion needs 2+ cameras (one camera's glare / body-in-frame must not
        # wedge the status). Board is "empty" only when EVERY camera agrees.
        motion = motion_votes >= 2 if n_cams >= 3 else motion_votes >= 1
        all_cleared = n_cams > 0 and cleared_votes == n_cams

        # keep the loop FAST while anything is happening, INCLUDING an event mid-
        # settle (a per-camera "changing" state), so events resolve promptly.
        changing_any = any(getattr(d, "_state", "idle") == "changing" for d in self.detectors.values())
        if motion or event_cands or changing_any:
            self._last_active = now
            self._last_activity = now
        self._stable_streak = 0 if motion else self._stable_streak + 1   # vision state only
        self._tick_n += 1

        with self._lock:
            if motion and self._darts:
                self.status = "Takeout in progress"
            elif not motion and self.status == "Takeout in progress":
                self.status = "Throw"

            # a HAND near the board = an explicit hand-sized event, or motion
            # sustained well past what a falling dart produces (~0.3 s). Used to
            # tell a pull (hand) from a bounce-out (no hand).
            self._motion_run = self._motion_run + 1 if motion else 0
            if hand_done or (self._darts and self._motion_run >= 15):
                self._last_hand = now

            # --- EVENT POOL: candidates arrive from per-camera FROZEN events
            # (each camera settles independently, so one dart's candidates land
            # within a short window). Commit once 2+ cameras agree on the spot —
            # no settle counters, no stability gate: the evidence is already a
            # settled Before/After pair per camera.
            # POST-COMMIT REFRACTORY (the reference dart_wait analogue): for a
            # short window after an accepted dart, new event candidates are
            # settle debris (wobble/glint of the dart that just landed) far
            # more often than a genuine rapid twin — drop them at the door.
            # Real twins arrive well past this window (min ~1s between darts);
            # replay-neutral by construction (rounds are 1.5s-spaced).
            wait_s = float(os.environ.get("WD_DART_WAIT", "0.5"))
            if event_cands and now - self._last_commit < wait_s:
                # DISTANCE-SCOPED (live 2026-07-22): settle debris wobbles AT the
                # fresh dart's spot — a candidate 100+mm away cannot be that
                # dart's glint. The blanket drop was eating real rim misses that
                # landed right after a neighbouring commit. 30mm keeps the
                # debris suppression, releases genuine far candidates.
                lx, ly = getattr(self, "_last_commit_xy", (None, None))
                if lx is None:
                    self._log("dart-wait-drop", n=len(event_cands))
                    event_cands = []
                else:
                    near = [c for c in event_cands
                            if math.hypot(c.x_mm - lx, c.y_mm - ly)
                            <= float(os.environ.get("WD_DART_WAIT_MM", "30.0"))]
                    if near:
                        self._log("dart-wait-drop", n=len(near))
                    event_cands = [c for c in event_cands if c not in near]
            self._pool.extend((now, c) for c in event_cands)
            # RIM candidates live LONGER (live 2026-07-22 rapid-fire misses):
            # the user throws again within ~2s, so the board is in motion when
            # the rescue could pair a lone rim candidate — by the time it's
            # still, the 1.5s TTL had destroyed the anchor. On-board keeps the
            # tight TTL (their fusion is immediate anyway).
            rim_ttl = float(os.environ.get("WD_RIM_TTL", "1.5"))
            def _ttl(c):
                return rim_ttl if math.hypot(c.x_mm, c.y_mm) > geo.R_DOUBLE_OUT * 1.02 else 1.5
            expired = [(t, c) for (t, c) in self._pool if now - t > _ttl(c)]
            self._pool = [(t, c) for (t, c) in self._pool if now - t <= _ttl(c)]
            if expired:
                # A candidate expiring uncommitted means a camera SAW something
                # land but cross-camera agreement never formed. Until now this
                # vanished with NO trace — the exact signature of the missed
                # rim darts (8/11 sits edge-on in two of three cameras; often
                # only cam1 makes a candidate). Recorded live 2026-07-22
                # 19:07-19:09: three separate throws vanished this way in a
                # 2.5-min session. LOG ONLY — no model, no commit, no state
                # change runs off this signal (USER RULE: live = tip_cnn
                # heatmap ONLY; Re-scan models stay behind the manual button).
                self._log("pool-expire",
                          pts=[{"cam": c.cam, "x": round(c.x_mm, 1),
                                "y": round(c.y_mm, 1)} for (_, c) in expired[:4]])

            # --- TAKEOUT: decided BEFORE commits on purpose. On the first still
            # tick after a pull, the removal event's candidates and the takeout
            # evidence arrive together — if commits ran first, a removal ghost
            # that slipped past the directional filter would commit, capture an
            # empty-board evidence patch, "verify" forever and wedge the board
            # (the phantom-S18 failure). Takeout is driven by the POSITION-
            # SPECIFIC per-dart check across cameras (exposure-compensated);
            # two consecutive "all gone" still ticks -> takeout.
            takeout = False
            if self._darts and not motion:
                # LATE EVIDENCE RE-CAPTURE: a dart whose commit-time windows
                # missed its pixels (parallax at the outer board) has no way to
                # verify a pull — retry against the empty reference while the
                # scene is still and the dart is fresh.
                for d in self._darts:
                    if not d.patches and not d.bounced and now - d.t_commit < 4.0:
                        self._capture_evidence(d, ref_fallback=True)
                        if d.patches:
                            self._log("late-evidence", hit=d.hit.name, cams=len(d.patches))
                # AUTO CENSUS (user-designed fast tier): ~2s after a commit,
                # the 400px model counts tips on all cameras once and ADDS any
                # dart the event pipeline missed (>=2-cam agreement, add-only —
                # extras are only logged). One pass per throw, ~0.5s.
                if (os.environ.get("WD_KP_CENSUS", "0") == "1"
                        and getattr(self, "_census_due", None)
                        and now >= self._census_due and not motion
                        and 1 <= len(self._darts) < 3):
                    self._census_due = None
                    try:
                        self._kp_census()
                    except Exception:
                        pass
                if self._committed_darts_gone(all_cleared):
                    self._gone_streak += 1
                else:
                    self._gone_streak = 0
                if self._gone_streak >= 2:
                    # HAND GATE (user report 2026-07-19: "I throw a 2nd dart and
                    # it thinks it's a takeout"): an incoming dart's flight can
                    # OCCLUDE the first dart's evidence patches on enough
                    # cameras to read "all gone" — but a real pull always shows
                    # a hand/arm, and a thrown dart never does. Require a hand
                    # sighting in the last 8s, OR every camera agreeing the
                    # whole board is empty (covers a dart falling off the board
                    # on its own — no hand there either, but the board IS bare).
                    if now - self._last_hand < 8.0 or all_cleared:
                        takeout = True
                    elif self._gone_streak == 2:
                        self._log("takeout-blocked-no-hand", all_cleared=all_cleared)
                # HAND-REACH TAKEOUT (reference hand-driven model): fire takeout
                # when a HAND reached in (a pull) and the board is still again —
                # regardless of whether each dart's patch verifies gone. A real
                # pulled dart leaves a hole/dent that keeps its reference-diff
                # vote alive, so _committed_darts_gone never returns True and the
                # board WEDGES on takeout (user: "reads correct but stays on
                # takeout after i pull"). The pull's hand event, not the residual
                # dent, decides the board is clearing. _last_hand is reset on
                # takeout so the next turn's throw is never cleared. Archive-
                # neutral: the replay has no hand events, so this never fires there.
                # DEFAULT OFF (live 2026-07-22 18:36: OVER-FIRED — sustained
                # throw/board motion also sets _last_hand, so a settled 3-dart
                # turn read as "pull done" and wiped mid-turn). The t_land
                # ordering fix in _committed_darts_gone addresses the real wedge;
                # this stays as an opt-in experiment only.
                if (not takeout and os.environ.get("WD_HAND_TAKEOUT", "0") == "1"
                        and self._last_hand > 0
                        and self._stable_streak >= int(os.environ.get("WD_HAND_TAKEOUT_STILL", "3"))
                        and float(os.environ.get("WD_HAND_TAKEOUT_MIN_S", "1.3"))
                            < now - self._last_hand
                            < float(os.environ.get("WD_HAND_TAKEOUT_MAX_S", "8.0"))):
                    self._log("hand-takeout", dt=round(now - self._last_hand, 1),
                              still=self._stable_streak)
                    takeout = True
            else:
                self._gone_streak = 0
            if not takeout:
                self._retract_phantoms()
            if takeout:
                self._darts.clear()
                self._pool.clear()
                self._shaft_lines.clear()
                self._gone_streak = 0
                for det in self.detectors.values():
                    det.clear_turn_ref()
                self.status = "Throw"
                self.event = "takeout"
                self._last_takeout = time.time()
                # Reset the pull-hand marker so the hand-reach takeout above does
                # NOT re-fire on the next turn's first throw (which lands within
                # seconds of this pull, while _last_hand would still be recent).
                self._last_hand = 0.0
                self._log("takeout")
                self._last_block_sig = None
                # do NOT re-baseline here: the pulling hand is often still in
                # frame, and a reference with a hand/shadow in it poisons the
                # ghost filter (removal diffs read as arrivals -> phantom darts).
                # The old empty reference stays valid — the board just returned
                # to exactly that state. Refresh it only once provably still.
                self._rebaseline_pending = True
                self._rebase_streak = 0
            elif not self._darts and self.status not in ("Takeout in progress", "Takeout"):
                self.status = "Throw"
            # FULL VISIT (3 darts): the turn is over — the only valid next event
            # is the pull. Say so explicitly: both the app and the monitor turn
            # yellow on any status containing "takeout" (1-2 dart visits can
            # still be pulled any time; this state just makes the full board
            # unambiguous and blocks phantom 4th darts below).
            if not takeout and len(self._darts) >= 3 and not motion:
                self.status = "Takeout wait"
            # auto-calibration owns the status while it runs — the APP reads the
            # status string ("calibrat" -> its calibrating glow), so a run
            # started from the monitor is visible there too, not just app->monitor
            if self.calibrating:
                self.status = "Calibrating"

            before = len(self._darts)
            # Identity of the darts present BEFORE this tick's commits. _commit()
            # re-sorts self._darts by ev_t, so a positional slice (self._darts[before:])
            # can point at the WRONG darts — a newly committed dart with an earlier
            # ev_t sorts to the front, and the slice then attaches evidence/snapshots
            # to pre-existing darts. Diff by identity instead.
            pre_ids = {id(d) for d in self._darts}
            # COMMIT FREEZE while a takeout is brewing or just fired: pulling
            # darts produces removal diffs that can sneak through the ghost
            # filter as dart-shaped candidates. Candidates wait in the pool
            # (1.5 s expiry kills removal ghosts; a real dart thrown in that
            # window still commits when the freeze lifts).
            # ... plus a HAND HOLD (the reference board rule, adopted 2026-07-18): from a
            # hand sighting until the board has been hand-free ~1.2s, no dart
            # may commit. Fixes "the dart we missed registers while I reach in
            # to pull" — the reach-in exposes the missed dart's diff and it
            # was committing mid-takeout. Real next throws are unaffected: a
            # throw is dart-sized (never sets _last_hand) and its candidates
            # outlive the hold via the pool.
            commit_ok = (self._gone_streak == 0 and now - self._last_takeout > 1.5
                         and now - self._last_hand > 1.2
                         # NEVER commit while the board is moving (the reference
                         # board's rule; user demand 2026-07-22): a pull's pause
                         # tick was committing removal ghosts as darts. A real
                         # throw's candidates arrive on a settled tick and
                         # outlive any brief motion via the pool.
                         and (not motion or os.environ.get("WD_COMMIT_STILL", "1") != "1")
                         # full visit: a 4th "dart" is always debris/ghost
                         and len(self._darts) < 3)
            # GUIDED RESCUE: a dart seen by only ONE camera would expire unpaired
            # (its 2+ cams commit bar is there for good reason). Before letting it
            # die, actively interrogate the OTHER cameras at its projected spot —
            # they may simply never have fired an event, but the dart is standing
            # in their view. One probe attempt per spot.
            # KEYPOINT RESCUE (WD_KP_RESCUE): a dart only ONE camera's event saw
            # would die at the 2-cam commit bar — the dominant close-twin miss
            # (the 2nd dart lands beside the 1st; other cameras' diffs are too
            # small or ghost-dropped). Ask the keypoints-as-objects detector
            # (kpnet, trained on our own throwdata) whether the OTHER cameras see
            # a tip at the projected spot RIGHT NOW — single-frame, so it needs
            # no event. Unlike the old probe rescue it is allowed NEAR existing
            # darts (that's where close twins live); the anti-phantom gate is
            # that the KP tip must be a NEW tip (not matching any committed
            # dart's own position in that camera).
            # PURE-HEATMAP-LIVE (user decision 2026-07-22): the live throw path
            # commits on the tip_cnn heatmap (openCV) ALONE. The tip_clean model
            # (and its v2 successor) is reserved for the user-triggered Re-scan
            # button — so these three KP helpers that peek with tip_clean DURING
            # a throw (rescue / dup-arbiter / move-arbiter) now default OFF. A
            # close/1-cam twin the heatmap misses is recovered by pressing
            # Re-scan, not by a model glancing in mid-throw. WD_KP_* can still
            # re-enable them per-board.
            if (os.environ.get("WD_KP_RESCUE", "0") == "1"
                    and self._pool and len(self._darts) < 3 and commit_ok and not motion):
                from . import kpnet
                if kpnet.v3_net() is not None:
                    clusters0 = self._cluster([c for _, c in self._pool], tuning.agree_mm)
                    for cl0 in clusters0:
                        if cl0["cams"] != 1 or cl0.get("score", 0.0) < 0.5:
                            continue
                        if math.hypot(cl0["x"], cl0["y"]) > geo.R_DOUBLE_OUT:
                            continue
                        key = ("kp", round(cl0["x"] / 5), round(cl0["y"] / 5))
                        if key in self._rescue_tried:
                            continue
                        self._rescue_tried[key] = now
                        have = {c.cam for _, c in self._pool
                                if math.hypot(c.x_mm - cl0["x"], c.y_mm - cl0["y"]) <= tuning.agree_mm}
                        for cam in self.hub.cameras:
                            if cam.index in have:
                                continue
                            calib = self.store.cfg.calibrations[cam.index]
                            fr = cam.latest()
                            if not calib.ready or fr is None:
                                continue
                            uv = calib.to_image(cl0["x"], cl0["y"])
                            if uv is None:
                                continue
                            best = None
                            for (tu, tv, conf) in kpnet.census_tips_fast(fr, calib):
                                b = calib.to_board(tu, tv)
                                if b is None:
                                    continue
                                # must be a NEW tip: not an existing dart re-seen
                                if any(math.hypot(d.x_mm - b[0], d.y_mm - b[1]) < 9.0
                                       for d in self._darts):
                                    continue
                                dd = math.hypot(b[0] - cl0["x"], b[1] - cl0["y"])
                                if dd <= tuning.agree_mm and (best is None or dd < best[0]):
                                    best = (dd, b, conf)
                            if best is not None:
                                self._pool.append((now, DartCandidate(cam.index, best[1][0], best[1][1],
                                                                      best[2], uv)))
                                self._log("kp-rescue", cam=cam.index,
                                          hit=geo.score_at(cl0["x"], cl0["y"]).name,
                                          conf=round(best[2], 2))
                                break
            if (os.environ.get("WD_RESCUE") == "1"
                    and self._pool and len(self._darts) < 3 and commit_ok and not motion):
                # GUIDED RESCUE of a genuinely-new-location dart that only ONE
                # camera fired an event for (the other two were occluded by a hand
                # or only re-detected existing darts). OFF by default: even with
                # the strict gates below it never fixed a miss on the replay set
                # (a 1-cam dart's other views genuinely don't confirm) and cost a
                # wire call by perturbing the position fusion. Kept for future data.
                # The gates that DID stop it creating phantoms:
                #   - high confidence (a crisp tip, not a smear)
                #   - on the SCORING board, not the surround (M-dart garbage)
                #   - a genuinely NEW location: far from every committed dart AND
                #     every other pending cluster (never a close-twin/settling spot)
                #   - the scene is settled (no event still in flight)
                #   - a second camera independently CONFIRMS a tip there
                # That combination is what a real 1-cam dart looks like and what a
                # phantom never does.
                clusters0 = self._cluster([c for _, c in self._pool], tuning.agree_mm)
                for cl0 in clusters0:
                    if cl0["cams"] != 1 or cl0.get("score", 0.0) < 0.85:
                        continue
                    if math.hypot(cl0["x"], cl0["y"]) > geo.R_DOUBLE_OUT:   # scoring board only
                        continue
                    if any(math.hypot(d.x_mm - cl0["x"], d.y_mm - cl0["y"]) < 22.0 for d in self._darts):
                        continue
                    if any(c2 is not cl0 and math.hypot(c2["x"] - cl0["x"], c2["y"] - cl0["y"]) < 22.0
                           for c2 in clusters0):
                        continue
                    if any(getattr(self.detectors[c.index], "_state", "idle") != "idle"
                           for c in self.hub.cameras):
                        continue
                    key = (round(cl0["x"] / 5), round(cl0["y"] / 5))
                    if key in self._rescue_tried:
                        continue
                    self._rescue_tried[key] = now
                    have = {c.cam for _, c in self._pool
                            if math.hypot(c.x_mm - cl0["x"], c.y_mm - cl0["y"]) <= tuning.agree_mm}
                    for cam in self.hub.cameras:
                        if cam.index in have:
                            continue
                        calib = self.store.cfg.calibrations[cam.index]
                        if not calib.ready:
                            continue
                        uv = calib.to_image(cl0["x"], cl0["y"])
                        if uv is None:
                            continue
                        cand = self.detectors[cam.index].probe_tip(uv[0], uv[1], calib, min_score=0.35)
                        if cand is not None and math.hypot(cand.x_mm - cl0["x"], cand.y_mm - cl0["y"]) <= tuning.agree_mm:
                            self._pool.append((now, cand))
                            self._log("rescue", cam=cam.index, hit=geo.score_at(cl0["x"], cl0["y"]).name,
                                      score=round(cand.area, 2))
                            break     # one confirming camera is enough for a commit
            # expire rescue markers so a later dart at the same spot gets its own try
            self._rescue_tried = {k: t for k, t in self._rescue_tried.items() if now - t < 5.0}
            # RIM RESCUE (default ON; live 2026-07-22, the M11 triple): a rim
            # miss often yields ONE good candidate — or two whose coarse blob
            # estimates scatter beyond even the 40mm rim tolerance (measured
            # 94mm) — so natural cross-camera agreement never forms and the
            # dart vanishes, only to be "found" later by the pull's hand-event
            # cycle. Point the LIVE tip_cnn heatmap (probe_tip: SAME model that
            # scores every throw, cumulative diff vs empty reference = its
            # training distribution) at the candidate's projected spot on the
            # cameras that didn't agree; a confirming tip within the rim
            # tolerance joins the pool and the cluster commits normally next
            # tick. Rule-compliant: no model beyond the live heatmap.
            # NOTE (live 2026-07-22 evening): the original `not motion` +
            # detectors-idle gates starved BOTH rescues to zero firings in
            # rapid play — the board is nearly always moving within a rescue's
            # window because the user simply throws again. Probing during
            # motion is safe: probe_tip reads the CURRENT frame, a hand there
            # just yields no rim tip, and the off-board PERSISTENCE gate at
            # commit (still tick + occupied spot) remains the phantom wall.
            if (os.environ.get("WD_RIM_RESCUE", "1") == "1"
                    and self._pool and len(self._darts) < 3 and commit_ok):
                rim_tol = max(tuning.agree_mm, float(os.environ.get("WD_RIM_AGREE_MM", "40.0")))
                rim_dedup = float(os.environ.get("WD_RIM_DEDUP_MM", "45.0"))
                clusters0 = self._cluster([c for _, c in self._pool], tuning.agree_mm)
                for cl0 in clusters0:
                    r0 = math.hypot(cl0["x"], cl0["y"])
                    if (cl0["cams"] != 1
                            or not (geo.R_DOUBLE_OUT * 1.02 < r0
                                    <= geo.R_DOUBLE_OUT * geo.R_BOARD_FACTOR)):
                        continue
                    # give natural agreement a beat before spending a probe
                    ages = [now - t for (t, c) in self._pool
                            if math.hypot(c.x_mm - cl0["x"], c.y_mm - cl0["y"]) <= tuning.agree_mm]
                    if not ages or max(ages) < 0.35:
                        continue
                    # DEDUP: a lone rim candidate within a rim-radius of an
                    # already-committed dart is that SAME dart's scattered
                    # leftover (each camera's rim estimate scatters 20-40mm), not
                    # a new throw. Rescuing it double-registers one physical dart
                    # (seen live: one rim dart -> two commits 28mm apart). A truly
                    # separate rim dart carries its own two-camera evidence and
                    # commits via the line-Election, so this only blocks the
                    # single-camera duplicate. 25mm was tighter than the scatter.
                    if any(math.hypot(d.x_mm - cl0["x"], d.y_mm - cl0["y"]) < rim_dedup
                           for d in self._darts):
                        continue
                    key = (round(cl0["x"] / 5), round(cl0["y"] / 5))
                    if key in self._rescue_tried:
                        continue
                    self._rescue_tried[key] = now
                    have = {c.cam for _, c in self._pool
                            if math.hypot(c.x_mm - cl0["x"], c.y_mm - cl0["y"]) <= rim_tol}
                    for cam in self.hub.cameras:
                        if cam.index in have:
                            continue
                        calib = self.store.cfg.calibrations[cam.index]
                        if not calib.ready:
                            continue
                        uv = calib.to_image(cl0["x"], cl0["y"])
                        if uv is None:
                            continue
                        # wider search window than the on-board probe: the
                        # coarse rim estimate itself is what scatters
                        cand = self.detectors[cam.index].probe_tip(
                            uv[0], uv[1], calib,
                            radius_px=int(os.environ.get("WD_RIM_PROBE_PX", "16")),
                            min_score=float(os.environ.get("WD_RIM_PROBE_SCORE", "0.3")))
                        if (cand is not None
                                and math.hypot(cand.x_mm - cl0["x"], cand.y_mm - cl0["y"]) <= rim_tol):
                            self._pool.append((now, cand))
                            self._log("rim-rescue", cam=cam.index,
                                      hit=geo.score_at(cl0["x"], cl0["y"]).name,
                                      score=round(getattr(cand, "area", 0.0), 2))
                            break     # one confirming camera reaches the 2-cam bar
            # HINT RESCUE (live 2026-07-22, the M11 triple's darts 2-3: ALL
            # cameras froze empty events — zero pool candidates, so nothing
            # above can recover). An empty event still leaves its largest
            # in-ring blob as a hint; point the live tip_cnn at the hint on
            # EVERY camera and require TWO independent CNN confirmations (the
            # normal commit bar). The blob only aims the probe — junk hints
            # (hand residue) fail the CNN and cost one rate-limited probe.
            while self._hint_queue and now - self._hint_queue[0][0] > 5.0:
                self._hint_queue.popleft()          # hints expire after 5s
            if (os.environ.get("WD_RIM_RESCUE", "1") == "1"
                    and self._hint_queue and len(self._darts) < 3 and commit_ok):
                rim_tol_h = max(tuning.agree_mm, float(os.environ.get("WD_RIM_AGREE_MM", "40.0")))
                rim_dedup_h = float(os.environ.get("WD_RIM_DEDUP_MM", "45.0"))
                for (ht, hx, hy) in list(self._hint_queue)[:3]:
                    key = (round(hx / 5), round(hy / 5))
                    if key in self._rescue_tried:
                        try:
                            self._hint_queue.remove((ht, hx, hy))
                        except ValueError:
                            pass
                        continue
                    if any(math.hypot(d.x_mm - hx, d.y_mm - hy) < rim_dedup_h for d in self._darts):
                        try:
                            self._hint_queue.remove((ht, hx, hy))
                        except ValueError:
                            pass
                        continue
                    self._rescue_tried[key] = now
                    try:
                        self._hint_queue.remove((ht, hx, hy))
                    except ValueError:
                        pass
                    got = []
                    for cam in self.hub.cameras:
                        calib = self.store.cfg.calibrations[cam.index]
                        if not calib.ready:
                            continue
                        uv = calib.to_image(hx, hy)
                        if uv is None:
                            continue
                        cand = self.detectors[cam.index].probe_tip(
                            uv[0], uv[1], calib,
                            radius_px=int(os.environ.get("WD_RIM_PROBE_PX", "16")),
                            min_score=float(os.environ.get("WD_RIM_PROBE_SCORE", "0.3")))
                        if (cand is not None
                                and math.hypot(cand.x_mm - hx, cand.y_mm - hy) <= rim_tol_h):
                            got.append(cand)
                    if len(got) >= 2:
                        for cand in got:
                            self._pool.append((now, cand))
                        self._log("hint-rescue", hit=geo.score_at(hx, hy).name,
                                  cams=len(got))
            if self._pool and len(self._darts) < 3 and commit_ok:
                clusters = self._cluster([c for _, c in self._pool], tuning.agree_mm)
                # LINE ELECTION FOR THE RIM (the reference board's ACTUAL fusion,
                # reference-engine fusion): it never
                # group candidates by point distance — two cameras AGREE when
                # their barrel LINES INTERSECT at a sane spot, because the
                # per-camera point estimate slides along the shaft while the
                # line stays true. Our rim candidates scatter 20-130mm in
                # POINTS (extrapolated homography) yet their lines cross at the
                # dart. So: rim candidates from DIFFERENT cameras that failed
                # point-grouping elect a position by intersecting their lines —
                # gates: non-degenerate angle (>=5 deg, their IntersectionAngle),
                # intersection inside the surround annulus, and near both
                # candidates' own tip ends. Scoped to the rim: on-board fusion
                # (which reads perfectly) is untouched.
                if os.environ.get("WD_RIM_ELECTION", "1") == "1":
                    lone = [cl for cl in clusters
                            if cl["cams"] == 1
                            and geo.R_DOUBLE_OUT * 1.02 < math.hypot(cl["x"], cl["y"])
                                < geo.R_DOUBLE_OUT * 1.6
                            and any(p[4] for p in cl["pts"])]
                    elect_max = float(os.environ.get("WD_ELECT_MAX_MM", "80.0"))
                    used = set()
                    for i in range(len(lone)):
                        if id(lone[i]) in used:
                            continue
                        for j in range(i + 1, len(lone)):
                            if id(lone[j]) in used:
                                continue
                            ca, cb = lone[i], lone[j]
                            if {p[0] for p in ca["pts"]} & {p[0] for p in cb["pts"]}:
                                continue          # need two DIFFERENT cameras
                            la = next(p[4] for p in ca["pts"] if p[4])
                            lb = next(p[4] for p in cb["pts"] if p[4])
                            (ax1, ay1), (ax2, ay2) = la
                            (bx1, by1), (bx2, by2) = lb
                            da = (ax2 - ax1, ay2 - ay1)
                            db = (bx2 - bx1, by2 - by1)
                            na = math.hypot(*da)
                            nb = math.hypot(*db)
                            if na < 1e-6 or nb < 1e-6:
                                continue
                            cross = da[0] * db[1] - da[1] * db[0]
                            if abs(cross) / (na * nb) < 0.087:   # <5 deg: degenerate
                                continue
                            t = ((bx1 - ax1) * db[1] - (by1 - ay1) * db[0]) / cross
                            ix = ax1 + t * da[0]
                            iy = ay1 + t * da[1]
                            if not (geo.R_DOUBLE_OUT * 1.02 < math.hypot(ix, iy)
                                    < geo.R_DOUBLE_OUT * 1.6):
                                continue
                            if (math.hypot(ix - ca["x"], iy - ca["y"]) > elect_max
                                    or math.hypot(ix - cb["x"], iy - cb["y"]) > elect_max):
                                continue
                            merged = {"pts": ca["pts"] + cb["pts"], "x": ix, "y": iy,
                                      "score": max(ca["score"], cb["score"]), "cams": 2,
                                      "elect_members": [(ca["x"], ca["y"]), (cb["x"], cb["y"])]}
                            used.add(id(ca)); used.add(id(cb))
                            clusters.append(merged)
                            self._log("rim-election",
                                      hit=geo.score_at(ix, iy).name,
                                      cams=[p[0] for p in merged["pts"]],
                                      d_pts=round(math.hypot(ca["x"] - cb["x"], ca["y"] - cb["y"]), 0))
                            break
                    if used:
                        clusters = [cl for cl in clusters if id(cl) not in used]
                # SHAFT-VOTE (WD_SHAFTVOTE, reference Election parity): recruit a
                # LINE-ONLY ballot from a camera that fired a dart event but saw
                # no tip (occluded by another dart — its shaft still painted the
                # diff). The line joins the barrel-line refinement for a cluster
                # that is ALREADY committing on >=2 real tip cameras; it never
                # creates a candidate, never votes a position, and the polar
                # blend + 12mm guard in _fuse_pts bound its influence exactly
                # like every other line. Closes the one structural gap vs the
                # reference Election: an occluded-tip camera now still votes.
                if os.environ.get("WD_SHAFTVOTE", "0") == "1" and self._shaft_lines:
                    self._shaft_lines = {ci: tl for ci, tl in self._shaft_lines.items()
                                         if now - tl[0] <= 1.5}
                    guard = float(os.environ.get("WD_LINEGUARD", "12"))
                    end_mm = float(os.environ.get("WD_SHAFT_END_MM", "22"))
                    for cl in clusters:
                        if cl["cams"] < getattr(tuning, "min_cams", 2):
                            continue
                        have = {p[0] for p in cl["pts"]}
                        extra = {}
                        for ci, (t_ln, ((p1, p2), (ex, ey))) in self._shaft_lines.items():
                            if ci in have:
                                continue
                            # the ballot's OWN tip end must sit near THIS cluster
                            # (its occluded tip is ~ where the other cams see the
                            # dart): stops a stale line, an adjacent dart's line,
                            # or a wrong-largest-component line from grabbing a
                            # cluster it doesn't belong to.
                            if math.hypot(ex - cl["x"], ey - cl["y"]) > end_mm:
                                continue
                            (lx1, ly1), (lx2, ly2) = p1, p2
                            ldx, ldy = lx2 - lx1, ly2 - ly1
                            lnn = math.hypot(ldx, ldy)
                            if lnn < 1e-6:
                                continue
                            # ...and pass close to it (same never-cross-a-segment
                            # 12mm guard as _line_tip)
                            if abs((cl["x"] - lx1) * ldy - (cl["y"] - ly1) * ldx) / lnn <= guard:
                                extra[ci] = (p1, p2)
                        if extra:
                            nx, ny = self._fuse_pts(cl["pts"], extra_lines=extra)
                            if (nx, ny) != (cl["x"], cl["y"]):
                                self._log("shaft-vote", cams=sorted(extra),
                                          hit=geo.score_at(nx, ny).name,
                                          d_mm=round(math.hypot(nx - cl["x"], ny - cl["y"]), 1))
                            cl["x"], cl["y"] = nx, ny
                # REGISTRATION LOCKOUT (user failsafe): one NEW dart per
                # window — a human cannot throw two darts in 0.8s, so a second
                # plain commit that fast is debris (wobble halo / split
                # cluster). Gate 425<437 taught the nuance: the KP twin
                # arbiter must stay OPEN through the lockout — a slow-settling
                # dart commits late, and its genuine quick follow-up is saved
                # only by the arbiter's two-physical-tips proof. So: timer
                # blocks unproven commits; census-verified twins pass. All
                # dup/wobble/ghost handling also keeps running (it only drops
                # or updates, never registers).
                def _locked(cx=None, cy=None):
                    # PROXIMITY-SCOPED lockout, evaluated at each commit
                    # attempt: within 0.8s of a commit, a second commit NEAR an
                    # existing dart (<20mm) is that dart's impact halo (flag
                    # 133137) — deferred. A FAR cluster stays allowed: a slow-
                    # settling dart's late commit legitimately coincides with
                    # the next real throw (blanket versions gated 425/430 by
                    # eating exactly those).
                    if time.time() - self._last_commit >= float(os.environ.get("WD_DART_LOCKOUT", "0.8")):
                        return False
                    if cx is None:
                        return True
                    return any(math.hypot(d.x_mm - cx, d.y_mm - cy) < 20.0 for d in self._darts)
                # Commit ON-BOARD (scoring) clusters BEFORE off-board M-darts so a
                # real dart claims its slot first; an off-board M in the SAME event
                # window is then recognisable as junk from that throw.
                clusters.sort(key=lambda c: math.hypot(c["x"], c["y"]) > geo.R_DOUBLE_OUT)
                for cl in clusters:
                    if cl["cams"] >= getattr(tuning, "min_cams", 2) and len(self._darts) < 3:
                        # OFF-BOARD LOCKOUT: when a dart lands, its throw sprays
                        # small shadow/flight/reflection blobs across the surround
                        # (and the CNN can hallucinate number-ring peaks); two that
                        # fall within agree_mm commit a phantom M-dart and STEAL a
                        # slot, locking out the real scoring dart thrown next
                        # (rounds 0461/0623/0965). An M-dart on the number ring/
                        # surround that commits within WD_OFFBOARD_LOCK_S of another
                        # commit is that spray junk, not a separate miss. TIME-scoped
                        # (not a 3-cam bar, which dropped real 2-cam M-darts and
                        # regressed the archive -9): a genuine M-dart is its own
                        # throw >=1s later and still commits.
                        if (math.hypot(cl["x"], cl["y"]) > geo.R_DOUBLE_OUT
                                and os.environ.get("WD_OFFBOARD_LOCKOUT", "1") == "1"
                                and now - self._last_commit < float(os.environ.get("WD_OFFBOARD_LOCK_S", "0.8"))):
                            self._log("offboard-lockout",
                                      hit=geo.score_at(cl["x"], cl["y"]).name,
                                      dt=round(now - self._last_commit, 2))
                            continue
                        # OFF-BOARD PERSISTENCE GATE (live 2026-07-22, phantom
                        # M18 during pickup): the board-face-masked hand gate
                        # can't see an arm working at the SURROUND, so two
                        # cameras' diffuse arm blobs fused and committed a
                        # phantom M. A hand is TRANSIENT — hold the commit while
                        # motion is live or the spot isn't actually occupied
                        # now; the candidates stay pooled and a real M-dart
                        # (physically stuck) commits 1-2 ticks later (an M
                        # scores 0, the delay is free). A hand's blob collapses
                        # and the pool expiry clears it instead.
                        if (math.hypot(cl["x"], cl["y"]) > geo.R_DOUBLE_OUT
                                and os.environ.get("WD_OFFBOARD_PERSIST", "1") == "1"):
                            # occupancy at the FUSED point alone ate a real M14
                            # (live 21:10:32 offboard-hold x4, motion=False):
                            # rim scatter puts the fused point 20-40mm from the
                            # dart, sampling empty surround. The dart IS at one
                            # of the member cameras' measured points — take the
                            # max over fused + members.
                            occ_bar = float(os.environ.get("WD_OFFBOARD_OCC", "0.35"))
                            occ_pts = [(cl["x"], cl["y"])] + [(p[1], p[2]) for p in cl["pts"][:4]]
                            occ = max(self._occupancy(px_, py_, "now") for (px_, py_) in occ_pts)
                            if motion or occ < occ_bar:
                                self._log("offboard-hold",
                                          hit=geo.score_at(cl["x"], cl["y"]).name,
                                          motion=bool(motion), occ=round(occ, 2))
                                continue
                        # never commit what can't be verified later: the fused position
                        # must project INSIDE the frame for 2+ cameras (a parallax-
                        # skewed surround point that doesn't would wedge the takeout)
                        proj_ok = 0
                        for cam in self.hub.cameras:
                            calib = self.store.cfg.calibrations[cam.index]
                            uv = calib.to_image(cl["x"], cl["y"]) if calib.ready else None
                            if uv and 0 <= uv[0] < 1280 and 0 <= uv[1] < 720:
                                proj_ok += 1
                        if proj_ok < 2:
                            self._log("proj-block", x=round(cl["x"], 1),
                                      y=round(cl["y"], 1), ok=proj_ok)
                            continue
                        # IMPACT-VIBRATION GUARD: a new cluster near a committed
                        # dart is often that dart nudged by the incoming throw
                        # (its displacement halo reads as an arrival) — committing
                        # it would burn the turn's 3rd slot on a duplicate. The
                        # discriminator is direction-aware: a genuine twin lands
                        # on board that was EMPTY before its event, a vibration
                        # halo sits on pixels the old dart already occupied.
                        dup = None
                        dup_d = 1e9
                        # 25 mm: a hard impact can swing the old dart's flight,
                        # and the halo's "tip" estimate lands well outside the
                        # old 10 mm band. Distance only decides who gets CHECKED
                        # — the evidence discriminator decides twin vs noise.
                        for d in self._darts:
                            dd = math.hypot(d.x_mm - cl["x"], d.y_mm - cl["y"])
                            if dd < 25.0 and dd < dup_d:
                                dup, dup_d = d, dd
                        if dup is not None:
                            # vibration = BOTH signals: the "arrival" lies on
                            # pixels the old dart already occupied AND the old
                            # dart no longer matches its own patch anywhere (it
                            # moved). Replay-measured twins always keep dup's
                            # patch-match alive (like>=2) even at 0.9 mm, so the
                            # conjunction never eats a real twin.
                            frac = self._occupancy(cl["x"], cl["y"], "before")
                            dth_, grays_, roff_ = self._presence_ctx()
                            _, dup_like, _ = self._presence_votes(dup, dth_, grays_, roff_)
                            if os.environ.get("WD_GUARD_DEBUG"):
                                print(f"GUARD dup_d={dup_d:.1f}mm frac={frac:.2f} "
                                      f"dup_like={dup_like} new={cl['x']:.1f},{cl['y']:.1f}"
                                      f" dup={dup.x_mm:.1f},{dup.y_mm:.1f}")
                            # frac >= 0.5: the "arrival" lies mostly ON the old
                            # dart's own pixels — replay-measured genuine twins
                            # never exceed 0.38, so this is the dart itself (a
                            # settle-wobble second event can keep 1-2 patch votes
                            # alive and must still not duplicate). The 0.35-0.5
                            # band keeps the stricter both-signals rule.
                            # coincidence: an impact halo never arrives alone — it
                            # is CAUSED by another dart landing, so it commits in
                            # the same instant as one: either that dart committed
                            # within the last ticks, or its cluster (a clean new
                            # dart AWAY from the committed ones) sits in this same
                            # batch. A lone twin throw has neither. (Replay: real
                            # overlap-twins at 12-18 mm show the same pixel
                            # signature as halos; only timing separates them.)
                            other_new = any(
                                cl2 is not cl and cl2["cams"] >= getattr(tuning, "min_cams", 2)
                                and all(math.hypot(d.x_mm - cl2["x"], d.y_mm - cl2["y"]) > 25.0
                                        for d in self._darts)
                                for cl2 in clusters)
                            coincident = (self._tick_n - self._last_commit_tick <= 3) or other_new
                            # SETTLING REFRACTORY (fires REGARDLESS of frac): a
                            # candidate a few mm from a dart committed under 0.7 s
                            # ago, while that dart still fully matches its own
                            # evidence (dup_like>=2), is that dart's own settling /
                            # vibration glint — not a new dart. The frac-gated
                            # vibration branch below MISSES this because a glint
                            # BESIDE the shaft has frac~0 (the phantom-3rd-dart bug,
                            # round_0378: T20/T20 -> T20/T20/T20). A real twin is a
                            # separate throw seconds later, so the 0.7 s window
                            # (settling is < 0.3 s) can never eat a real twin.
                            # DUPLICATE RE-READ (widened settling refractory): the
                            # original rule fired only within 8mm/0.7s, but flagged
                            # real games show the SAME stuck shaft re-committing as
                            # its fused tip jitters up to the full 25mm search
                            # radius (105935 ~23mm cluster, 143150, 153831). The
                            # SAFE discriminator is TIME, not distance: within 0.7s
                            # of a dart committing there cannot be a second REAL
                            # dart (a human throws darts >=1s apart), so any near
                            # cluster in that window — with the original still
                            # fully present (dup_like>=2) — is that dart re-detected.
                            # Time-gated so it is robust under the replay mock clock
                            # (which advances `now` +1.5s per level): a real
                            # cross-throw twin (>=1.5s apart, down to 2mm) always
                            # has dt>=1.5 and commits; only a same-burst re-read
                            # (<0.7s) is dropped. dup_d<25 is just the search radius.
                            dt = now - (dup.t_land or dup.t_commit)
                            if dup_like >= 2 and dt < 0.7:
                                # KP TWIN ARBITER: dt measures commit-to-cluster,
                                # not landing-to-landing — a slow-settling dart
                                # commits late, so a quick REAL follow-up throw can
                                # land inside the 0.7s window (live flag 220614:
                                # 3rd S20 eaten as a re-read of the 2nd). Before
                                # dropping, ask the keypoint model: TWO physical
                                # tips near the spot = a real tight twin -> commit.
                                if os.environ.get("WD_KP_DUPCHECK", "0") == "1":
                                    from . import kpnet
                                    n_near = 0
                                    if kpnet.v3_net() is not None:
                                        for _cam in self.hub.cameras:
                                            _cal = self.store.cfg.calibrations[_cam.index]
                                            _fr = _cam.latest()
                                            if not _cal.ready or _fr is None:
                                                continue
                                            _c = 0
                                            for (_u, _v, _cf) in kpnet.census_tips_fast(_fr, _cal):
                                                _b = _cal.to_board(_u, _v)
                                                if _b and math.hypot(_b[0] - dup.x_mm, _b[1] - dup.y_mm) < 25.0:
                                                    _c += 1
                                            n_near = max(n_near, _c)
                                    if n_near >= 2:
                                        self._log("kp-twin-keep", near=dup.hit.name, tips=n_near)
                                        self._commit(cl["x"], cl["y"], cl["cams"])
                                        self._pool = [(t, c) for (t, c) in self._pool
                                                      if math.hypot(c.x_mm - cl["x"], c.y_mm - cl["y"]) > tuning.agree_mm]
                                        continue
                                self._log("dup-drop", near=dup.hit.name,
                                          d_mm=round(dup_d, 1), frac=round(frac, 2),
                                          like=dup_like, dt=round(dt, 2))
                                self._pool = [(t, c) for (t, c) in self._pool
                                              if math.hypot(c.x_mm - cl["x"], c.y_mm - cl["y"]) > tuning.agree_mm]
                                continue
                            # (A coincident-halo drop lived here briefly and
                            # gated 429<438 — it ate replay twins/misses whose
                            # split clusters mimic the halo signature. The
                            # principled fix is pose-verification of near-dart
                            # commits once the axis model ships.)
                            # WOBBLE RE-COMMIT (live flags 115347/122031, the
                            # post-grace dup class): a candidate closer than any
                            # physically possible twin (<6mm — barrel bodies
                            # collide) whose original no longer matches its own
                            # patch anywhere (dup_like==0: it MOVED) is the same
                            # dart re-detected after a nudge — update in place.
                            # The halo's tip lands BESIDE the shaft so frac<0.35
                            # and every branch below missed it (1.9mm/3.9mm dups
                            # committed). A genuine 0.9mm-tip twin keeps
                            # dup_like>=2 (replay-measured) and never enters.
                            # GHOST CHECK (2026-07-22 audit): like the frac
                            # branch below, require the spot to be occupied NOW
                            # — a pull's removal ghost within 6mm would
                            # otherwise be absorbed as a "move" and re-capture
                            # evidence from the EMPTY scene (permanently-true
                            # patch match -> takeout wedge).
                            if (dup_d < 6.0 and dup_like == 0
                                    and self._occupancy(cl["x"], cl["y"], "now") >= 0.35):
                                dup.x_mm, dup.y_mm = cl["x"], cl["y"]
                                dup.hit = geo.score_at(cl["x"], cl["y"])
                                dup.off_board = (
                                    dup.hit.multiplier == 0
                                    and math.hypot(dup.x_mm, dup.y_mm) > geo.R_DOUBLE_OUT
                                    and os.environ.get("WD_OFFBOARD_NOHOLD", "1") == "1")
                                dup.cams = max(dup.cams, cl["cams"])
                                dup.patches.clear()
                                dup.suspect_since = None
                                dup.t_commit = time.time()
                                dup.commit_tick = self._tick_n
                                self._capture_evidence(dup)
                                self.event = f"moved:{dup.hit.name}"
                                self._log("wobble-move", hit=dup.hit.name,
                                          d_mm=round(dup_d, 1), like=dup_like)
                                self._pool = [(t, c) for (t, c) in self._pool
                                              if math.hypot(c.x_mm - cl["x"], c.y_mm - cl["y"]) > tuning.agree_mm]
                                continue
                            if frac >= 0.5 or (frac >= 0.35 and dup_like == 0):
                                if dup_like >= 2 and (dup_d < 10.0 or coincident):
                                    # MASS OVERRIDE (user design, replay-validated on
                                    # the 120 real flags): a wobble moves a dart a
                                    # hair — a thin halo, small changed mass. A real
                                    # piggyback dart adds a DART-SIZED blob of new
                                    # pixels on previously-empty board, which a
                                    # vibration physically cannot paint. Compare this
                                    # event's off-footprint mass with the turn's own
                                    # committed arrivals (self-calibrating per
                                    # camera/lighting): dart-sized -> it IS a dart,
                                    # commit it instead of eating it. Upper bound 3.0
                                    # rejects lighting flips (mass everywhere).
                                    if os.environ.get("WD_MASS_OVERRIDE", "0") == "1":
                                        cur = self._event_mass(off_footprint=True)
                                        ratios = []
                                        for _ci, _m in cur.items():
                                            _refs = [d2.arrival_mass[_ci] for d2 in self._darts
                                                     if d2.arrival_mass.get(_ci, 0) >= 200]
                                            if _refs:
                                                ratios.append(_m / float(np.median(_refs)))
                                        med_r = float(np.median(ratios)) if ratios else 0.0
                                        lo = float(os.environ.get("WD_MASS_RATIO", "0.5"))
                                        if lo <= med_r <= 3.0:
                                            self._log("mass-twin-keep", near=dup.hit.name,
                                                      ratio=round(med_r, 2), frac=round(frac, 2),
                                                      d_mm=round(dup_d, 1), mass=cur)
                                            self._commit(cl["x"], cl["y"], cl["cams"])
                                            self._pool = [(t, c) for (t, c) in self._pool
                                                          if math.hypot(c.x_mm - cl["x"], c.y_mm - cl["y"]) > tuning.agree_mm]
                                            continue
                                        self._log("mass-veto", ratio=round(med_r, 2), mass=cur)
                                    # the old dart still fully matches its own
                                    # evidence — it neither left nor moved. This
                                    # "arrival" on its pre-existing pixels is its
                                    # own impact halo (flight/shaft swing from the
                                    # next dart landing): pure noise. Drop it —
                                    # committing would double-register, moving
                                    # would corrupt a good dart's position.
                                    self._log("noise-drop", near=dup.hit.name,
                                              d_mm=round(dup_d, 1), frac=round(frac, 2))
                                    self._pool = [(t, c) for (t, c) in self._pool
                                                  if math.hypot(c.x_mm - cl["x"], c.y_mm - cl["y"]) > tuning.agree_mm]
                                    continue
                                if dup_like >= 2:
                                    if _locked():
                                        continue
                                    # far, high-overlap, but arrived ALONE: a real
                                    # twin leaning across the old dart — commit it
                                    self._commit(cl["x"], cl["y"], cl["cams"])
                                    self._pool = [(t, c) for (t, c) in self._pool
                                                  if math.hypot(c.x_mm - cl["x"], c.y_mm - cl["y"]) > tuning.agree_mm]
                                    continue
                                if self._occupancy(cl["x"], cl["y"], "now") < 0.35:
                                    # nothing is physically there NOW: this is the
                                    # removal ghost of a fallen/pulled dart, not a
                                    # move — drop it (the bounce-out logic in the
                                    # takeout check scores the dead dart as a Miss)
                                    self._log("ghost-drop", x=round(cl["x"], 1), y=round(cl["y"], 1))
                                    self._pool = [(t, c) for (t, c) in self._pool
                                                  if math.hypot(c.x_mm - cl["x"], c.y_mm - cl["y"]) > tuning.agree_mm]
                                    continue
                                # MOVE-OR-TWIN arbiter (flag 135625: the 3rd
                                # dart landed touching the 2nd and was consumed
                                # as "moved 0.9mm" — pixels can't separate a
                                # nudge from a touching twin, but TIP COUNT
                                # can). Before accepting a move, ask the census
                                # model: two physical tips near the spot = a
                                # real twin -> commit it as a new dart instead.
                                if os.environ.get("WD_KP_MOVECHECK", "0") == "1" and len(self._darts) < 3:
                                    from . import kpnet
                                    n_near = 0
                                    if kpnet.v3_net() is not None:
                                        for _cam in self.hub.cameras:
                                            _cal = self.store.cfg.calibrations[_cam.index]
                                            _fr = _cam.latest()
                                            if not _cal.ready or _fr is None:
                                                continue
                                            _c = 0
                                            for (_u, _v, _cf) in kpnet.census_tips_fast(_fr, _cal):
                                                _b = _cal.to_board(_u, _v)
                                                if _b and math.hypot(_b[0] - dup.x_mm, _b[1] - dup.y_mm) < 25.0:
                                                    _c += 1
                                            n_near = max(n_near, _c)
                                    if n_near >= 2:
                                        self._log("kp-move-twin", near=dup.hit.name, tips=n_near)
                                        self._commit(cl["x"], cl["y"], cl["cams"])
                                        self._pool = [(t, c) for (t, c) in self._pool
                                                      if math.hypot(c.x_mm - cl["x"], c.y_mm - cl["y"]) > tuning.agree_mm]
                                        continue
                                dup.x_mm, dup.y_mm = cl["x"], cl["y"]
                                dup.hit = geo.score_at(cl["x"], cl["y"])
                                # keep off_board honest after a re-score: a dart
                                # nudged INTO the scoring area must regain its
                                # takeout hold (and vice versa) — stale flags
                                # let the hand-recency skip drop a real dart
                                dup.off_board = (
                                    dup.hit.multiplier == 0
                                    and math.hypot(dup.x_mm, dup.y_mm) > geo.R_DOUBLE_OUT
                                    and os.environ.get("WD_OFFBOARD_NOHOLD", "1") == "1")
                                dup.cams = max(dup.cams, cl["cams"])
                                dup.patches.clear()
                                dup.suspect_since = None
                                dup.t_commit = time.time()
                                dup.commit_tick = self._tick_n
                                self._capture_evidence(dup)
                                self.event = f"moved:{dup.hit.name}"
                                self._log("moved", hit=dup.hit.name, d_mm=round(dup_d, 1),
                                          frac=round(frac, 2), like=dup_like)
                                self._pool = [(t, c) for (t, c) in self._pool
                                              if math.hypot(c.x_mm - cl["x"], c.y_mm - cl["y"]) > tuning.agree_mm]
                                continue
                        if _locked(cl["x"], cl["y"]):
                            continue          # stays pooled; commits when the window opens
                        self._commit(cl["x"], cl["y"], cl["cams"])
                        # flush the pool near the commit AND near an Election
                        # cluster's member points (they sit far from the
                        # intersection — leftovers would re-elect a duplicate)
                        near_pts = [(cl["x"], cl["y"])] + cl.get("elect_members", [])
                        self._pool = [(t, c) for (t, c) in self._pool
                                      if all(math.hypot(c.x_mm - mx, c.y_mm - my) > tuning.agree_mm
                                             for (mx, my) in near_pts)]

                # CONSUME shaft ballots whose tip end landed on a now-committed
                # dart, so one ballot votes at most once and can NEVER refine the
                # NEXT throw's cluster (the stale-line blocker: a tight follow-up
                # into the same sector, where the occluded camera fires no new
                # event to clear the line). Covers every commit path above.
                if self._shaft_lines and self._darts:
                    self._shaft_lines = {
                        ci: tl for ci, tl in self._shaft_lines.items()
                        if all(math.hypot(tl[1][1][0] - d.x_mm, tl[1][1][1] - d.y_mm) > 20.0
                               for d in self._darts)}

            if len(self._darts) > before:
                # Freeze each new dart's per-camera evidence (classic): the
                # raw board crop + its isolated event diff + the tip position.
                if before == 0:
                    self.dart_snaps = []          # a new turn starts a fresh grid
                for d in [d for d in self._darts if id(d) not in pre_ids]:
                    self._capture_evidence(d)
                    snap = {"label": d.hit.name, "cells": {}}
                    for cam in self.hub.cameras:
                        det = self.detectors[cam.index]
                        calib = self.store.cfg.calibrations[cam.index]
                        params = getattr(det, "_last_params", None)
                        dc = getattr(det, "_last_dc", None)
                        if params is None or not calib.ready:
                            continue
                        uv = calib.to_image(d.x_mm, d.y_mm)
                        xy = tipnet.board_to_crop(uv[0], uv[1], params) if uv else None
                        snap["cells"][cam.index] = {
                            "img": tipnet.crop(frames[cam.index], params),
                            "diff": None if dc is None else dc.copy(),
                            "xy": xy,
                        }
                    self.dart_snaps.append(snap)
                self.status = "Throw"

            # BOUNCE-OUT -> MISS (user 2026-07-23: "a bounce-out must COUNT as a
            # Miss"): a dart that hit and fell off leaves no stuck dart, so the
            # engine used to register nothing and the visit stalled. The detector
            # logs a bounce-diag when a dart-sized blob PEAKS mid-event then
            # vanishes with a CNN tip; those hits pool here. Commit one as an
            # M<sector> that counts as a throw and scores 0. GATED HARD against
            # false Misses: no real dart committed recently (a real dart's
            # one-camera empty-settle is NOT a bounce — that was the T1/S1 false
            # fire), no hand, board has room, still, and either 2-camera OR one
            # strong camera (CNN score + peak). WD_BOUNCE_MISS=0 disables.
            if (os.environ.get("WD_BOUNCE_MISS", "1") == "1" and self._bounce_pool
                    and len(self._darts) < 3 and not motion
                    and now - self._last_commit > float(os.environ.get("WD_BOUNCE_QUIET_S", "2.0"))
                    and now - self._last_hand > 2.0 and now - self._last_takeout > 1.5):
                self._bounce_pool = deque((e for e in self._bounce_pool if now - e[0] < 1.5), maxlen=24)
                clusters = []
                for (t, cam, peak, x, y, hit, score) in self._bounce_pool:
                    if x is None:
                        continue
                    placed = False
                    for cl in clusters:
                        tol = 45.0 if math.hypot(x, y) > geo.R_DOUBLE_OUT else 25.0
                        if math.hypot(cl["x"] - x, cl["y"] - y) <= tol:
                            cl["cams"].add(cam); cl["score"] = max(cl["score"], score)
                            cl["peak"] = max(cl["peak"], peak); cl["pts"].append((x, y))
                            cl["x"] = sum(p[0] for p in cl["pts"]) / len(cl["pts"])
                            cl["y"] = sum(p[1] for p in cl["pts"]) / len(cl["pts"])
                            placed = True
                            break
                    if not placed:
                        clusters.append({"x": x, "y": y, "cams": {cam}, "score": score,
                                         "peak": peak, "pts": [(x, y)]})
                for cl in clusters:
                    strong1 = (cl["score"] >= float(os.environ.get("WD_BOUNCE_SCORE", "0.7"))
                               and cl["peak"] >= float(os.environ.get("WD_BOUNCE_PEAK_BAR", "60")))
                    if len(cl["cams"]) >= 2 or strong1:
                        sh = geo.score_at(cl["x"], cl["y"])
                        num = sh.number if sh else 0
                        nd = CommittedDart(cl["x"], cl["y"],
                                           geo.Hit(num, 0, f"M{num}", "Outside", 0), len(cl["cams"]))
                        nd.bounced = True
                        nd.t_commit = now
                        nd.t_land = now
                        self._darts.append(nd)
                        self._last_commit = now
                        self.status = "Throw"
                        self.event = f"bounce:{nd.hit.name}"
                        self._log("bounce-miss", hit=nd.hit.name, cams=sorted(cl["cams"]),
                                  score=round(cl["score"], 2), peak=int(cl["peak"]))
                        self._bounce_pool.clear()
                        break

            # idle re-baseline of the empty reference (relaxed bar, no darts)
            self._clear_streak = self._clear_streak + 1 if (all_cleared and not self._darts) else 0
            if self._clear_streak >= tuning.clear_frames * self._tscale:
                for cam in self.hub.cameras:
                    self.detectors[cam.index].set_reference(frames[cam.index])
                self._clear_streak = 0
            # STILLNESS WATCHDOG (classic standby): if absolutely nothing
            # has moved for 90 s, self-heal — fresh reference from the current still
            # scene and a clean state. No wedge (poisoned reference, stale darts,
            # phantom) can survive it; in real play darts never sit that long
            # mid-turn, and an idle board only gets its reference refreshed.
            if now - self._last_activity > 90.0:
                self._last_activity = now
                if self._darts:
                    self.event = "stale-reset"
                    self._last_takeout = time.time()
                    self._log("stale-reset", why=self._gone_debug)
                self._darts.clear()
                self._pool.clear()
                self._gone_streak = 0
                self._rebaseline_pending = False   # taking the reference right now
                self.status = "Throw"
                for cam in self.hub.cameras:
                    self.detectors[cam.index].set_reference(frames[cam.index])

            # deferred post-takeout re-baseline: wait for a genuinely still,
            # hand-free scene (no motion, every event machine idle) for a few
            # consecutive ticks before snapshotting the new empty reference
            if self._rebaseline_pending and not self._darts:
                still = not motion and all(
                    getattr(self.detectors[cam.index], "_state", "idle") == "idle"
                    for cam in self.hub.cameras)
                self._rebase_streak = self._rebase_streak + 1 if still else 0
                if self._rebase_streak >= 3:
                    for cam in self.hub.cameras:
                        self.detectors[cam.index].set_reference(frames[cam.index])
                    self._rebaseline_pending = False
                    self._rebase_streak = 0
            elif self._rebaseline_pending:
                # a new dart landed before the refresh — keep the old reference
                self._rebaseline_pending = False

        self._emit()

    def _commit(self, x_mm: float, y_mm: float, cams: int) -> None:
        # TEST HARNESS (WD_KP_PRIMARY=1): the 400px census model MEASURES every
        # dart — the committed position snaps to the nearest KP tip cluster.
        # Event detection/triggering unchanged; only the position source swaps.
        if os.environ.get("WD_KP_PRIMARY", "0") == "1":
            from . import kpnet
            if kpnet.v3_net() is not None:
                pts = []
                for cam in self.hub.cameras:
                    calib = self.store.cfg.calibrations[cam.index]
                    fr = cam.latest()
                    if not calib.ready or fr is None:
                        continue
                    for (u, v, conf) in kpnet.census_tips_fast(fr, calib):
                        b = calib.to_board(u, v)
                        if b:
                            pts.append((cam.index, b[0], b[1]))
                cls = []
                for cam, x, y in pts:
                    for cl in cls:
                        if math.hypot(cl["x"] - x, cl["y"] - y) <= 18.0:
                            cl["p"].append((x, y)); cl["c"].add(cam)
                            cl["x"] = sum(a for a, _ in cl["p"]) / len(cl["p"])
                            cl["y"] = sum(b for _, b in cl["p"]) / len(cl["p"])
                            break
                    else:
                        cls.append({"x": x, "y": y, "p": [(x, y)], "c": {cam}})
                best = None
                for cl in cls:
                    if len(cl["c"]) < 2:
                        continue
                    d = math.hypot(cl["x"] - x_mm, cl["y"] - y_mm)
                    if d <= 20.0 and (best is None or d < best[0]):
                        best = (d, cl["x"], cl["y"])
                if best is not None:
                    x_mm, y_mm = best[1], best[2]
        # FULL-DART POSE entry correction (WD_POSE_ENTRY=1): the barrel occludes
        # the entry hole, so each camera's visible tip reads SHORT along the dart
        # axis. Nudge every cluster member K mm along its camera's pose axis in
        # board space, then re-fuse. No pose match -> position unchanged.
        # DEFAULT OFF (final verdict 2026-07-18): +2 on the AD-import gate
        # (439) but -2 flat at every K under OUR calibration (435 vs 437) —
        # the ring GRACE already absorbs the physical entry-occlusion bias at
        # the scoring boundary, so the axis shift double-compensates live.
        # Keep for AD-mode experiments and future re-tuning.
        if os.environ.get("WD_POSE_ENTRY", "0") == "1":
            try:
                fixed = self._pose_entry(x_mm, y_mm)
                if fixed is not None:
                    x_mm, y_mm = fixed
            except Exception:
                pass
        hit = geo.score_at(x_mm, y_mm)
        # TIME+SPACE DUP GUARD: two physical darts cannot land within ~45mm of
        # each other in under ~1.2s — a throw's flight + settle takes longer and
        # consecutive throws are seconds apart. So a commit this close to a
        # JUST-committed dart is the SAME dart re-registered: per-camera rim
        # scatter, or a hard rim/number-wire hit recoiling the board so one dart
        # smears across two positions and each fuses separately (flagged live:
        # M8+M8 44mm, M11+M8 40mm, M14+M9 38mm — every one in the same second).
        # A genuine close twin is a separate throw seconds later and passes.
        # SCOPED OFF-BOARD ONLY: the scatter/shake double is a RIM/surround
        # phenomenon (edge-on cameras, hard-surface recoil). ON-BOARD twins are
        # real and land genuinely close in the same sector (validated: the only
        # archive rounds this would wrongly merge are on-board S1+S1/S5+S5/S12+S12
        # twins), so the guard fires only when the new read is off the scoring
        # face — where two darts truly can't be that close that fast.
        if (os.environ.get("WD_DUP_GUARD", "1") == "1"
                and math.hypot(x_mm, y_mm) > geo.R_DOUBLE_OUT):
            _now = time.time()
            _dmm = float(os.environ.get("WD_DUP_MM", "45.0"))
            _ds = float(os.environ.get("WD_DUP_S", "1.2"))
            for _d in self._darts:
                _gap = _now - getattr(_d, "t_commit", 0.0)
                if _gap < _ds and math.hypot(_d.x_mm - x_mm, _d.y_mm - y_mm) < _dmm:
                    self._log("dup-guard", hit=hit.name, near=_d.hit.name,
                              d_mm=round(math.hypot(_d.x_mm - x_mm, _d.y_mm - y_mm), 1),
                              dt=round(_gap, 2))
                    return
        tick = getattr(self, "_tick_n", 0)
        # ev_t: when this dart's event FIRST hit the pool — a late commit (a
        # rescued or slow-confirmed dart) must take its place in the THROW
        # ORDER, not the commit order (user: "sometimes it reads darts in the
        # wrong order"). The throws list is rebuilt from _darts on every state
        # push, so sorting here fixes both display and the game feed.
        ev_t = min((t for t, c in self._pool
                    if math.hypot(c.x_mm - x_mm, c.y_mm - y_mm) <= self.store.cfg.tuning.agree_mm),
                   default=time.time())
        nd = CommittedDart(x_mm, y_mm, hit, cams, t_commit=time.time(), commit_tick=tick,
                           ev_t=ev_t, t_land=time.time())
        # OFF-BOARD M-dart: scores 0 and its surround blob (a bounce mark / scuff)
        # can persist forever. Flag it so takeout treats it like a bounce-out and
        # it can NEVER wedge the board (the reference engine never feeds an off-board blob to
        # its takeout model either). WD_OFFBOARD_NOHOLD=0 restores the old hold.
        if (hit.multiplier == 0 and math.hypot(x_mm, y_mm) > geo.R_DOUBLE_OUT
                and os.environ.get("WD_OFFBOARD_NOHOLD", "1") == "1"):
            nd.off_board = True
        self._darts.append(nd)
        self._darts.sort(key=lambda d: getattr(d, "ev_t", d.t_commit))
        # record this arrival's off-footprint heatmap mass NOW (the turn
        # reference rolls forward below, so the frozen Before still predates
        # this dart) — the self-calibrating per-turn "one dart's worth".
        try:
            nd.arrival_mass = self._event_mass(off_footprint=True)
        except Exception:
            nd.arrival_mass = {}
        self.status = "Throw"
        self.event = f"throw:{hit.name}"
        self._last_commit = time.time()
        self._last_commit_xy = (nd.x_mm, nd.y_mm)   # dart-wait is distance-scoped
        self._last_commit_tick = tick
        self._census_due = time.time() + 2.2   # auto-census (off by default)
        # freeze this turn's camera pictures for the manual 800px re-scan
        for _c in self.hub.cameras:
            _f = _c.latest()
            if _f is not None:
                if not hasattr(self, "_turn_frames"):
                    self._turn_frames = {}
                self._turn_frames[_c.index] = _f.copy()
        # roll each camera's TURN REFERENCE forward to now (this dart included), so
        # the next throw is diffed against a board that already holds it — a re-read
        # of an existing dart then shows zero change (the reference board's per-throw model)
        for det in self.detectors.values():
            det.snap_turn_ref()
        self._log("throw", hit=hit.name, x=round(x_mm, 1), y=round(y_mm, 1), cams=cams)

    def motion_state(self) -> str:
        """classic vision state machine, derived from the current signals —
        WAIT (not running) / HAND (something moving, no darts) / TAKEOUT (movement
        while darts are on the board = pulling them) / DART (a throw just landed) /
        STABLE (board settled, ready)."""
        if not self.running:
            return "WAIT"
        now = time.time()
        motion = any(getattr(o, "motion", False) for o in self.last_obs.values())
        if self.status == "Takeout in progress" or now - self._last_takeout < 1.0:
            return "TAKEOUT"
        if motion:
            return "TAKEOUT" if self._darts else "HAND"
        if now - self._last_commit < 0.7:
            return "DART"
        return "STABLE"

    def health_snapshot(self) -> dict:
        """Thread-safe view of the engine internals for /api/health. Reads
        _darts/_pool/_decision_log under the lock so an HTTP handler can never
        observe them mid-mutation by the engine thread (len() on a list being
        rebuilt, or iterating a deque while it's appended)."""
        with self._lock:
            return {
                "running": self.running,
                "status": self.status,
                "motionState": self.motion_state(),
                "numThrows": len(self._darts),
                "pending": len(self._pool),
                "stableStreak": self._stable_streak,
                "clearStreak": self._clear_streak,
                "goneDebug": dict(self._gone_debug),
                "log": list(self._decision_log),
            }

    def _kp_census(self) -> None:
        """Fast-tier per-throw census (add-only). See kp_recheck for the manual
        full version; this one uses the 400px model and runs automatically."""
        from . import kpnet
        if kpnet.v3_net() is None:
            return
        pts = []
        for cam in self.hub.cameras:
            calib = self.store.cfg.calibrations[cam.index]
            fr = cam.latest()
            if not calib.ready or fr is None:
                continue
            for (u, v, conf) in kpnet.census_tips_fast(fr, calib):
                b = calib.to_board(u, v)
                if b and math.hypot(*b) <= geo.R_DOUBLE_OUT * geo.R_BOARD_FACTOR:
                    pts.append((cam.index, b[0], b[1]))
        clusters = []
        for cam, x, y in pts:
            for cl in clusters:
                if math.hypot(cl["x"] - x, cl["y"] - y) <= 18.0:
                    cl["pts"].append((cam, x, y)); cl["cams"].add(cam)
                    cl["x"] = sum(p[1] for p in cl["pts"]) / len(cl["pts"])
                    cl["y"] = sum(p[2] for p in cl["pts"]) / len(cl["pts"])
                    break
            else:
                clusters.append({"x": x, "y": y, "pts": [(cam, x, y)], "cams": {cam}})
        for cl in clusters:
            if len(cl["cams"]) >= 2 and len(self._darts) < 3                     and not any(math.hypot(d.x_mm - cl["x"], d.y_mm - cl["y"]) < 14.0
                                for d in self._darts):
                self._commit(cl["x"], cl["y"], len(cl["cams"]))
                self._capture_evidence(self._darts[-1], ref_fallback=True)
                self._log("census-add", hit=self._darts[-1].hit.name)

    def _pose_entry(self, x_mm: float, y_mm: float) -> tuple[float, float] | None:
        """FULL-DART POSE correction for one commit (WD_POSE_ENTRY=1). The pose
        model reads tip+shaft+flight per dart; the three are collinear, so the
        axis says which way the dart points INTO the board. The visible tip sits
        SHORT of the true entry hole (the barrel occludes it), so each cluster
        member's board position is extended K mm (WD_POSE_K, default 1.2) along
        that axis before re-fusing. Pose runs once per camera per tick (cached —
        one commit's three members share it). Returns the corrected (x, y), or
        None to keep the original."""
        from . import kpnet
        if kpnet.pose_net() is None:
            return None
        K = float(os.environ.get("WD_POSE_K", "1.8"))
        tol = self.store.cfg.tuning.agree_mm
        members = [c for _, c in self._pool
                   if math.hypot(c.x_mm - x_mm, c.y_mm - y_mm) <= tol]
        if not members:
            return None       # e.g. a census-add commit — no pool cluster behind it
        tick = getattr(self, "_tick_n", 0)
        if getattr(self, "_pose_cache", None) is None or self._pose_cache[0] != tick:
            self._pose_cache = (tick, {})
        poses = self._pose_cache[1]
        cams = {cam.index: cam for cam in self.hub.cameras}
        pts, n_fix = [], 0
        for c in members:
            uv = getattr(c, "tip_uv", None)
            cx, cy = c.x_mm, c.y_mm
            calib = self.store.cfg.calibrations[c.cam]
            if uv is not None and calib.ready:
                if c.cam not in poses:
                    cam = cams.get(c.cam)
                    fr = cam.latest() if cam is not None else None
                    poses[c.cam] = kpnet.pose_darts(fr, calib) if fr is not None else []
                best = None
                for p in poses[c.cam]:
                    if p["axis"] is None:
                        continue
                    d = math.hypot(p["tip"][0] - uv[0], p["tip"][1] - uv[1])
                    if d <= 15.0 and (best is None or d < best[0]):
                        best = (d, p["axis"])
                if best is not None:
                    du, dv = best[1]
                    # image-px axis -> board-mm direction at the tip
                    b0 = calib.to_board(uv[0], uv[1])
                    b1 = calib.to_board(uv[0] + 20.0 * du, uv[1] + 20.0 * dv)
                    if b0 and b1:
                        gx, gy = b1[0] - b0[0], b1[1] - b0[1]
                        g = math.hypot(gx, gy)
                        if g > 1e-6:
                            nx, ny = cx + K * gx / g, cy + K * gy / g
                            # sanity: the K mm nudge must stay near the original
                            if math.hypot(nx - cx, ny - cy) <= 8.0:
                                cx, cy = nx, ny
                                n_fix += 1
            pts.append((c.cam, cx, cy, uv, getattr(c, "line", None)))
        if n_fix == 0:
            return None
        fx, fy = self._fuse_pts(pts)
        self._log("pose-entry", k=K, fixed=n_fix, of=len(pts),
                  cams=" ".join(f"{i}:{len(poses[i])}" for i in sorted(poses)),
                  d_mm=round(math.hypot(fx - x_mm, fy - y_mm), 2))
        return fx, fy

    def edit_dart(self, index: int, ring: str = "", x_mm: float | None = None,
                  y_mm: float | None = None) -> dict:
        """Human override (monitor). Two modes: cycle the ring S/T/D (tap a
        throw), or MOVE the dart to an exact board position (select its slot,
        click the board) — the player's eyes are the final authority."""
        with self._lock:
            if not (0 <= index < len(self._darts)):
                return {"ok": False, "error": "no such dart"}
            d = self._darts[index]
            if x_mm is not None and y_mm is not None:
                # MOVE mode: exact position from the user's board click
                d.x_mm, d.y_mm = float(x_mm), float(y_mm)
                d.hit = geo.score_at(d.x_mm, d.y_mm)
                d.patches.clear()
                d.suspect_since = None
                self._capture_evidence(d, ref_fallback=True)
                self._log("user-move", i=index, now=d.hit.name)
                name = d.hit.name
            else:
                # RING mode: keep the angle, snap radius to the band centre
                a = math.atan2(d.y_mm, d.x_mm)
                r_cur = math.hypot(d.x_mm, d.y_mm)
                ring = ring.upper()
                if ring == "T":
                    r = 103.0
                elif ring == "D":
                    r = 166.0
                else:
                    r = r_cur if (15.9 < r_cur <= 99.0 or 107.0 < r_cur <= 162.0) else \
                        (60.0 if r_cur <= 103.0 else 134.0)
                d.x_mm, d.y_mm = r * math.cos(a), r * math.sin(a)
                d.hit = geo.score_at(d.x_mm, d.y_mm)
                self._log("user-edit", i=index, now=d.hit.name)
                name = d.hit.name
        self._emit(force=True)
        return {"ok": True, "name": name}

    def _kp_recheck_anchored(self) -> dict:
        """MOTION-ANCHORED re-scan (WD_RESCAN_ANCHORED) — the safe design. A plain
        whole-board scan invents phantom darts on wires/numbers; this instead ZOOMS
        the pose model on the spots where darts are KNOWN to be (the committed darts,
        each landed from a real motion event), re-pins each tip precisely (fixes a
        misread) and splits a merged twin (recovers a hidden dart). A full-frame pass
        runs too, but a tip FAR from every committed dart is added ONLY when it is
        HIGH-confidence and the count is under 3 — so the risky part is gated + bounded
        (never exceeds 3). ADDITIVE-ONLY: never deletes."""
        from . import kpnet
        if (time.time() - self._last_activity < 1.0
                or any(getattr(d, "_state", "idle") == "changing" for d in self.detectors.values())):
            return {"ok": False, "error": "board is moving — wait a moment and re-scan again"}
        CROP = 260
        pts = []                          # (cam, bx, by, conf)
        with self._lock:
            saved = getattr(self, "_turn_frames", {})
            anchors = [(d.x_mm, d.y_mm) for d in self._darts]
            for cam in self.hub.cameras:
                calib = self.store.cfg.calibrations[cam.index]
                fr = cam.latest()
                if fr is None:
                    fr = saved.get(cam.index)
                if not calib.ready or fr is None:
                    continue
                h, w = fr.shape[:2]
                # (a) ANCHORED zoom: a tight full-res crop around each committed
                # dart -> the pose model separates a merged twin and pins the tip
                # more precisely than the shrunk full frame.
                for (bx, by) in anchors:
                    uv = calib.to_image(bx, by)
                    if not uv:
                        continue
                    x0 = max(0, min(w - CROP, int(uv[0]) - CROP // 2))
                    y0 = max(0, min(h - CROP, int(uv[1]) - CROP // 2))
                    sub = fr[y0:y0 + CROP, x0:x0 + CROP]
                    if sub.shape[0] < 60 or sub.shape[1] < 60:
                        continue
                    for (u, v, c) in kpnet.v3_dart_tips(sub):
                        b = calib.to_board(u + x0, v + y0)
                        if b and math.hypot(*b) <= 340.0:
                            pts.append((cam.index, b[0], b[1], c))
                # (b) full-frame pass -> catches a dart with NO committed anchor
                # (a throw the live pipeline missed entirely).
                for (u, v, c) in kpnet.v3_dart_tips(fr):
                    b = calib.to_board(u, v)
                    if b and math.hypot(*b) <= 340.0:
                        pts.append((cam.index, b[0], b[1], c))
            # cluster across cameras (same radii as kp_recheck; v3_dart_tips already
            # dedups, and the anchored crops overlap the full-frame hits)
            clusters = []
            for cam, x, y, conf in pts:
                for cl in clusters:
                    r_cl = 9.0 if math.hypot(x, y) <= geo.R_DOUBLE_OUT else 15.0
                    if math.hypot(cl["x"] - x, cl["y"] - y) <= r_cl:
                        cl["pts"].append((cam, x, y)); cl["cams"].add(cam)
                        cl["conf"] = max(cl["conf"], conf)
                        cl["x"] = sum(p[1] for p in cl["pts"]) / len(cl["pts"])
                        cl["y"] = sum(p[2] for p in cl["pts"]) / len(cl["pts"])
                        break
                else:
                    clusters.append({"x": x, "y": y, "pts": [(cam, x, y)],
                                     "cams": {cam}, "conf": conf})
            clusters = [c for c in clusters if len(c["cams"]) >= 2 or c["conf"] >= 0.50]
            added, fixed = [], []
            # MATCH + FIX. The live per-throw read (3-camera triangulation) is
            # finer than any single-view tip, so small disagreements keep the
            # live read. But a fused MULTI-camera cluster that CLEARLY lands in
            # a different segment is photo evidence of a misread (user demand:
            # "fix the wrong score!") — gates: 2+ cameras agreeing, >=6mm apart
            # (a hair's-width wire call is where the live read stays boss), and
            # the segment name actually changes. Never deletes; adds stay gated.
            claimed = set()                       # clusters that ARE an existing dart
            # Assign each cluster to its NEAREST committed dart (<=30mm). The
            # earlier greedy first-dart-wins gather STOLE a neighbour's camera
            # evidence (flag 180839 replay: the S20 dart absorbed the T20 dart's
            # cam2 view, so the T20 fix failed its 2-cam gate).
            assign = {}
            order = []
            for ci, cl in enumerate(clusters):
                best_d, best_dd = None, 30.0
                for di, d in enumerate(self._darts):
                    dd = math.hypot(d.x_mm - cl["x"], d.y_mm - cl["y"])
                    if dd < best_dd:
                        best_d, best_dd = di, dd
                if best_d is not None:
                    order.append((best_dd, ci, best_d))
            # closest cluster claims its dart first; a later cluster may join
            # that dart's support ONLY with disjoint cameras (occlusion split —
            # the T20->S20 multi-view case). A cluster SHARING a camera with the
            # dart's views is physically a SEPARATE dart (one camera never sees
            # the same tip twice) and stays unclaimed for the ADD step — flag
            # 185315: the S11 next to a D14 was swallowed as a "view" and the
            # add of a real dart was silently lost.
            for _dd, ci, di in sorted(order):
                sup_cams = (set().union(*[clusters[c]["cams"] for c in assign[di]])
                            if assign.get(di) else set())
                if sup_cams & clusters[ci]["cams"]:
                    continue
                assign.setdefault(di, []).append(ci)
                claimed.add(ci)
            # SECOND-CHANCE MULTI-VIEW FUSION (flag 180839): a partially occluded
            # tip projects differently per camera, so one dart's views can land
            # >9mm apart and split into single-cam clusters — each alone fails
            # the 2-cam gate even though the cameras AGREE on the segment
            # (cam1+cam2 both said S20 at r=117-119 for a dart committed
            # T20@106.5). Fuse ALL of this dart's assigned clusters conf-weighted
            # and judge on the UNION of cameras.
            for di, d in enumerate(self._darts):
                sup = [clusters[ci] for ci in assign.get(di, [])]
                if not sup:
                    continue
                wsum = sum(c2["conf"] * len(c2["pts"]) for c2 in sup)
                fx = sum(c2["x"] * c2["conf"] * len(c2["pts"]) for c2 in sup) / wsum
                fy = sum(c2["y"] * c2["conf"] * len(c2["pts"]) for c2 in sup) / wsum
                cams_u = set().union(*[c2["cams"] for c2 in sup])
                ddf = math.hypot(d.x_mm - fx, d.y_mm - fy)
                new_hit = geo.score_at(fx, fy)
                if new_hit.name != d.hit.name and len(cams_u) >= 2 and ddf >= 6.0:
                    old = d.hit.name
                    d.x_mm, d.y_mm = fx, fy
                    d.hit = new_hit
                    d.cams = max(d.cams, len(cams_u))
                    self._capture_evidence(d, ref_fallback=True)
                    fixed.append(f"{old}->{new_hit.name}")
            for ci, cl in enumerate(clusters):
                if ci in claimed or len(self._darts) >= 3:
                    continue
                if any(math.hypot(d.x_mm - cl["x"], d.y_mm - cl["y"]) < 8.0 for d in self._darts):
                    continue                      # <8mm from a dart = the same dart, not a twin
                near_anchor = any(math.hypot(bx - cl["x"], by - cl["y"]) < 40.0 for (bx, by) in anchors)
                # a TWIN beside a real dart -> trust a decent hit; a FAR one (no
                # anchor) -> only a strong MULTI-camera hit (a lone single-cam far
                # tip is the phantom risk that set random darts before).
                if (near_anchor and (len(cl["cams"]) >= 2 or cl["conf"] >= 0.50)) or \
                        (not near_anchor and len(cl["cams"]) >= 2 and cl["conf"] >= 0.60):
                    self._commit(cl["x"], cl["y"], len(cl["cams"]))
                    added.append(self._darts[-1].hit.name)
                    self._capture_evidence(self._darts[-1], ref_fallback=True)
            self._log("kp-recheck-anchored", seen=len(clusters), added=added,
                      fixed=fixed, darts=[d.hit.name for d in self._darts])
        self._emit(force=True)
        return {"ok": True, "seen": len(clusters), "added": added, "fixed": fixed,
                "removed": [], "unconfirmed": [], "darts": [d.hit.name for d in self._darts]}

    def kp_recheck(self) -> dict:
        """USER-TRIGGERED full-board re-scan (monitor button): the keypoint model
        examines every camera's current frame, clusters the tips it finds across
        cameras (>=2-cam agreement, same bar as commits), and reconciles with the
        committed darts. MISSING darts (a cluster with no committed dart nearby)
        are added; EXTRA committed darts (no cluster support) are only REPORTED —
        auto-removal burned us once (the phantom-retract regression), the user
        can Reset if the extras are wrong."""
        from . import kpnet
        # MOTION-ANCHORED re-scan (safe design): zoom on committed-dart spots +
        # bounded far-dart adds. Opt-in; falls back to the paths below when off.
        if os.environ.get("WD_RESCAN_ANCHORED", "1") == "1" and kpnet.v3_net() is not None:
            return self._kp_recheck_anchored()
        # v3 A/B TEST (WD_RESCAN_V3=1): drive the census from the rig-matching v3
        # pose model and stay ADDITIVE-ONLY (no removal) so a live test is safe.
        v3_mode = (os.environ.get("WD_RESCAN_V3", "1") == "1" and kpnet.v3_net() is not None)
        if (kpnet.v3_net() if v3_mode else kpnet.net()) is None:
            return {"ok": False, "error": "keypoint model not installed — update the board "
                                          "(⬆ Update on this page) to get the detection models"}
        # STILLNESS GATE (flag 132152: a re-scan raced a landing dart, the
        # fresh photo caught mid-motion frames, saw 1 of 3 darts and the
        # photo-wins removal deleted a REAL one): never judge a moving board.
        if (time.time() - self._last_activity < 1.0
                or any(getattr(d, "_state", "idle") == "changing" for d in self.detectors.values())):
            return {"ok": False, "error": "board is moving — wait a moment and re-scan again"}
        pts = []
        with self._lock:
            saved = getattr(self, "_turn_frames", {})
            for cam in self.hub.cameras:
                calib = self.store.cfg.calibrations[cam.index]
                fr = cam.latest()          # FRESH capture (user spec); saved turn
                if fr is None:             # frame only as fallback
                    fr = saved.get(cam.index)
                if not calib.ready or fr is None:
                    continue
                tips = list(kpnet.v3_dart_tips(fr) if v3_mode else kpnet.dart_tips(fr))
                # ZOOM PASS (tight groups, flag 133445: three S20s seen as ONE):
                # re-detect on magnified crops around every first-pass tip and
                # every committed dart's spot — merged tips separate at 1.6x.
                centers = [(u, v) for (u, v, _) in tips]
                for d in self._darts:
                    uv = calib.to_image(d.x_mm, d.y_mm)
                    if uv:
                        centers.append(uv)
                for (u, v, c) in ([] if v3_mode else kpnet.dart_tips_zoom(fr, centers)):
                    if all(math.hypot(u - a, v - b) > 6 for (a, b, _) in tips):
                        tips.append((u, v, c))
                for (u, v, conf) in tips:
                    b = calib.to_board(u, v)
                    # accept the SURROUND too (user: re-scan removed his M20 —
                    # a standing miss had no photo support because its tip was
                    # filtered here; misses are darts and keep their slot)
                    if b and math.hypot(*b) <= 340.0:
                        pts.append((cam.index, b[0], b[1], conf))
            # cluster across cameras (9mm — tight-twin tips sit 8-15mm apart;
            # the old 18mm radius re-merged darts the zoom pass separated)
            clusters = []
            for cam, x, y, conf in pts:
                for cl in clusters:
                    # calibration EXTRAPOLATES beyond the double ring, so per-
                    # cam agreement degrades with radius — widen the cluster
                    # radius for surround (miss) tips
                    r_cl = 9.0 if math.hypot(x, y) <= geo.R_DOUBLE_OUT else 15.0
                    if math.hypot(cl["x"] - x, cl["y"] - y) <= r_cl:
                        cl["pts"].append((cam, x, y)); cl["cams"].add(cam)
                        cl["conf"] = max(cl["conf"], conf)
                        cl["x"] = sum(p[1] for p in cl["pts"]) / len(cl["pts"])
                        cl["y"] = sum(p[2] for p in cl["pts"]) / len(cl["pts"])
                        break
                else:
                    clusters.append({"x": x, "y": y, "pts": [(cam, x, y)],
                                     "cams": {cam}, "conf": conf})
            # MANUAL context: >=2 cams as usual, but a stacked tight group can be
            # resolvable in only ONE camera (flag 133445: cam1 alone separates
            # three S20s; the others see a wall of darts). A tip's board position
            # from one camera is still exact (it lies on the board plane), so a
            # CONFIDENT single-camera cluster counts when the user asked.
            clusters = [c for c in clusters
                        if len(c["cams"]) >= 2 or c["conf"] >= 0.50]
            added, extras, fixed = [], [], []
            used = set()
            # 1) CORRECT: match each cluster to its nearest committed dart; if
            # the segment differs (or the position is clearly off), move the
            # dart there and rescore. Small agreements stay untouched — the
            # event pipeline measures finer than the model's boxes.
            for cl in clusters:
                best = None
                for i, d in enumerate(self._darts):
                    if i in used:
                        continue
                    dd = math.hypot(d.x_mm - cl["x"], d.y_mm - cl["y"])
                    if dd < 30.0 and (best is None or dd < best[0]):
                        best = (dd, i)
                if best is None:
                    continue
                dd, i = best
                used.add(i)
                d = self._darts[i]
                new_hit = geo.score_at(cl["x"], cl["y"])
                if new_hit.name != d.hit.name or dd > 6.0:
                    old_name = d.hit.name
                    d.x_mm, d.y_mm = cl["x"], cl["y"]
                    d.hit = new_hit
                    d.cams = max(d.cams, len(cl["cams"]))
                    self._capture_evidence(d, ref_fallback=True)
                    if new_hit.name != old_name:
                        fixed.append(f"{old_name}->{new_hit.name}")
            # 2) REMOVE before ADD (user reconciliation design: the fresh
            # photo wins existence disputes, and freeing slots first lets a
            # corrected dart take the removed duplicate's place).
            removed = []
            if clusters and not v3_mode:      # v3 A/B test: additive-only, never delete
                owner = set()
                for cl in clusters:
                    best = None
                    for i, d in enumerate(self._darts):
                        if i in owner:
                            continue
                        dd = math.hypot(d.x_mm - cl["x"], d.y_mm - cl["y"])
                        if dd < 30.0 and (best is None or dd < best[0]):
                            best = (dd, i)
                    if best is not None:
                        owner.add(best[1])
                dth_, grays_, roff_ = self._presence_ctx()
                drop = set()
                for i, d in enumerate(self._darts):
                    if i in owner:
                        continue
                    # DUP PAIR: another held dart closer than any physically
                    # possible twin (<6mm, barrels collide) -> the unmatched
                    # one is a duplicate, removed with no further proof
                    is_dup = any(j != i and math.hypot(d.x_mm - d2.x_mm, d.y_mm - d2.y_mm) < 6.0
                                 for j, d2 in enumerate(self._darts) if j not in drop)
                    _, like_v, _dbg = self._presence_votes(d, dth_, grays_, roff_)
                    n_p = len(d.patches)
                    # the ONE veto (flag 132435: model missed a standing D6):
                    # a lone unmatched dart whose own evidence still fully
                    # vouches for it stays — everything else the photo
                    # overrules (user: "photo wins"). "Fully" is scaled to the
                    # evidence the dart can physically HAVE (flag 140435: an
                    # edge dart holds only ONE patch by parallax, matched it
                    # 1/1, and the flat like>=2 bar deleted a real dart).
                    # M-darts (surround) are EXEMPT entirely: model recall is
                    # weakest out there and removing a miss can't fix a score.
                    vouch = max(1, min(2, n_p))
                    if is_dup or (like_v < vouch and math.hypot(d.x_mm, d.y_mm) <= geo.R_DOUBLE_OUT):
                        drop.add(i)
                for i in sorted(drop, reverse=True):
                    removed.append(self._darts[i].hit.name)
                    self.event = f"undo:{self._darts[i].hit.name}"
                    del self._darts[i]
            # 3) ADD: clusters that matched no dart (matched darts keep their
            # ev_t, so throw ORDER carries over; additions take the end slots)
            for cl in clusters:
                if not any(math.hypot(d.x_mm - cl["x"], d.y_mm - cl["y"]) < 14.0 for d in self._darts)                         and len(self._darts) < 3:
                    self._commit(cl["x"], cl["y"], len(cl["cams"]))
                    added.append(self._darts[-1].hit.name)
                    self._capture_evidence(self._darts[-1], ref_fallback=True)
            for d in self._darts:
                if not any(math.hypot(d.x_mm - c["x"], d.y_mm - c["y"]) < 14.0 for c in clusters):
                    extras.append(d.hit.name)
            self._log("kp-recheck", seen=len(clusters), added=added,
                      fixed=fixed, removed=removed, extras=extras)
        self._emit(force=True)
        return {"ok": True, "seen": len(clusters), "added": added, "fixed": fixed,
                "removed": removed,
                "unconfirmed": extras,
                "darts": [d.hit.name for d in self._darts]}

    def evidence_series(self) -> list:
        """Thread-safe per-committed-dart evidence over time for the flag capture:
        each dart's identity + its [(tick, votes, like, n_patches), ...] history.
        A REAL dart's votes/like hold high; a PHANTOM's fade — the signal that
        separates a double-registration from a genuine dart."""
        with self._lock:
            return [{
                "hit": d.hit.name, "x_mm": round(d.x_mm, 1), "y_mm": round(d.y_mm, 1),
                "cams": d.cams, "commit_tick": d.commit_tick,
                "ev_hist": list(d.ev_hist),   # (tick, votes, like, n_patches)
            } for d in self._darts]

    def _retract_phantoms(self) -> None:
        """Remove a committed SCORING dart that never confirmed on a 2nd camera.
        Measured on flagged real games (evidence_series over 24 flags): a phantom
        — a fleeting glint that won a 2-cam TIP agreement at commit but doesn't
        actually match a dart on later frames — has its presence votes stuck at
        <=1 for its whole life, while EVERY real dart is confirmed by >=2 cameras.
        After a short grace it cannot be a real dart, so retract it (it added
        phantom points; the "read the 2nd dart twice" complaint). SCORING darts
        only: a low-vote Outside/miss scores 0 anyway and dropping it would just
        lose the throw count. Gated (WD_PHANTOM_RETRACT), never touches a lone dart."""
        # DISABLED by default (2026-07-09): live-flagged games showed max-votes<=1
        # is NOT phantom-exclusive — a REAL dart only 1 camera can verify over time
        # (occluded by another dart / poor angle) also sits at votes<=1, so this
        # retracted real darts ("it removed the first dart when I threw the 2nd").
        # The votes signal alone can't separate a phantom from a 1-camera real dart;
        # needs a near-duplicate / new-mass gate. Off until that's built + verified.
        if os.environ.get("WD_PHANTOM_RETRACT", "0") != "1" or len(self._darts) < 2:
            return
        keep = []
        for d in self._darts:
            max_votes = max((s[1] for s in d.ev_hist), default=99)
            if (not d.bounced and d.hit.multiplier > 0
                    and len(d.ev_hist) >= 12 and max_votes <= 1):
                self._log("phantom-retract", hit=d.hit.name,
                          maxVotes=max_votes, samples=len(d.ev_hist))
                self.event = f"undo:{d.hit.name}"
                continue                       # drop the phantom
            keep.append(d)
        if len(keep) != len(self._darts):
            self._darts = keep

    def _near_committed(self, x: float, y: float, tol: float) -> bool:
        return any(math.hypot(d.x_mm - x, d.y_mm - y) <= tol for d in self._darts)

    def _capture_evidence(self, d: CommittedDart, ref_fallback: bool = False) -> None:
        """Evidence patch + ARRIVAL MASK per camera: which pixels this dart
        actually changed (After vs the event's frozen Before — reference-
        independent). Presence is later judged ONLY on those pixels; a window
        that mostly missed the dart (parallax reprojection) has too few and
        the camera ABSTAINS instead of matching background against background
        forever. ref_fallback: mask against the empty reference instead (late
        re-capture for darts whose commit-time windows missed their pixels —
        without evidence a pull can't be verified and takeout waits out the
        no-evidence grace)."""
        for cam in self.hub.cameras:
            det = self.detectors[cam.index]
            calib = self.store.cfg.calibrations[cam.index]
            if not calib.ready:
                continue
            uv = calib.to_image(d.x_mm, d.y_mm)
            g = getattr(det, "_last_gray", None)
            b = getattr(det, "_last_before", None)
            if ref_fallback:
                b = det._empty_gray
            if uv is None or g is None:
                continue
            xi, yi = int(uv[0]), int(uv[1])
            gh, gw_ = g.shape
            if not (0 <= xi < gw_ and 0 <= yi < gh):
                continue
            rr = 16
            ys, xs = max(0, yi - rr), max(0, xi - rr)
            win = g[ys:yi + rr, xs:xi + rr]
            if b is not None and b.shape == g.shape:
                dm = win.astype(np.int16) - b[ys:yi + rr, xs:xi + rr].astype(np.int16)
                dm = np.abs(dm - int(np.median(dm)))
                mask = dm > self.store.cfg.tuning.diff_threshold
                if int(mask.sum()) >= 25:
                    d.patches[cam.index] = (win.copy(), mask, xi, yi)

    def _event_mass(self, off_footprint: bool = True) -> dict:
        """Full-frame changed-pixel mass of the CURRENT event (gray vs the
        event's frozen Before), per camera, at ::2 subsample — the user's
        'heatmap size' signal. Validated on the 120 real flagged turns:
        missed-dart turns carry ~+0.8 darts of unexplained mass (73% > +0.4),
        phantom-double turns ~-0.7 (62% < -0.4), count-correct turns 0.00.
        off_footprint=True counts only pixels that were EMPTY before the event:
        a vibration halo lies on the old dart's own body, a real new dart
        plants a dart-sized blob on fresh board."""
        dth = self.store.cfg.tuning.diff_threshold
        out = {}
        for cam in self.hub.cameras:
            det = self.detectors[cam.index]
            g = getattr(det, "_last_gray", None)
            b = getattr(det, "_last_before", None)
            e = det._empty_gray
            if g is None or b is None or g.shape != b.shape:
                continue
            gs = g[::2, ::2].astype(np.int16)
            bs = b[::2, ::2].astype(np.int16)
            dm = gs - bs
            dm = np.abs(dm - int(np.median(dm)))
            mask = dm > dth
            if off_footprint:
                if e is None or e.shape != g.shape:
                    continue
                es = e[::2, ::2].astype(np.int16)
                off = int(np.median(bs - es))
                occupied = np.abs(bs - es - off) > dth
                mask = mask & ~occupied
            out[cam.index] = int(mask.sum())
        return out

    def _occupancy(self, x_mm: float, y_mm: float, which: str) -> float:
        """Median (across cameras) fraction of this event's arrival-mask pixels
        that differ from the empty reference in a chosen frame.
        which="before" (the event's frozen Before): a genuine twin lands on
        board that was empty before its event (~0); an impact-vibration halo
        lies on the old dart's own body (high).
        which="now" (the current frame): is anything physically there NOW —
        a removal ghost's spot reads empty (~0), a real dart reads high.
        Exposure-compensated with the whole-frame median."""
        dth = self.store.cfg.tuning.diff_threshold
        fracs = []
        for cam in self.hub.cameras:
            det = self.detectors[cam.index]
            calib = self.store.cfg.calibrations[cam.index]
            g = getattr(det, "_last_gray", None)
            b = getattr(det, "_last_before", None)
            e = det._empty_gray
            if not calib.ready or g is None or b is None or e is None:
                continue
            if b.shape != g.shape or e.shape != g.shape:
                continue
            uv = calib.to_image(x_mm, y_mm)
            if uv is None:
                continue
            xi, yi = int(uv[0]), int(uv[1])
            gh, gw_ = g.shape
            if not (0 <= xi < gw_ and 0 <= yi < gh):
                continue
            rr = 16
            ys, xs = max(0, yi - rr), max(0, xi - rr)
            wg = g[ys:yi + rr, xs:xi + rr].astype(np.int16)
            wb = b[ys:yi + rr, xs:xi + rr].astype(np.int16)
            we = e[ys:yi + rr, xs:xi + rr].astype(np.int16)
            dm = wg - wb
            dm = np.abs(dm - int(np.median(dm)))
            mask = dm > dth                      # this event's arrival pixels
            n = int(mask.sum())
            if n < 25:
                continue
            src, wsrc = (b, wb) if which == "before" else (g, wg)
            off = int(np.median(src[::8, ::8].astype(np.int16) - e[::8, ::8].astype(np.int16)))
            om = np.abs(wsrc - we - off) > dth   # occupied in the chosen frame?
            fracs.append(int((om & mask).sum()) / n)
        if not fracs:
            return 0.0
        fracs.sort()
        return fracs[len(fracs) // 2]

    def _presence_ctx(self):
        """Shared inputs for evidence checks: diff threshold, per-camera current
        grays, and a per-camera GLOBAL exposure offset vs the empty reference —
        exposure is frame-wide, occlusion is local, so compensating with the
        whole-frame median keeps a window-sized occluder from reading as an
        exposure shift."""
        dth = self.store.cfg.tuning.diff_threshold
        grays = {c.index: self.detectors[c.index]._last_gray for c in self.hub.cameras}
        ref_off = {}
        for c in self.hub.cameras:
            g = grays.get(c.index)
            ew = self.detectors[c.index]._empty_gray
            if g is not None and ew is not None and g.shape == ew.shape:
                ref_off[c.index] = int(np.median(
                    g[::8, ::8].astype(np.int16) - ew[::8, ::8].astype(np.int16)))
        return dth, grays, ref_off

    def _presence_votes(self, d: CommittedDart, dth, grays, ref_off):
        """Per-camera evidence that dart d is still on the board. Two signals,
        both exposure-compensated and evaluated ONLY on the dart's own
        arrival-mask pixels:
          like — those pixels still look like the commit-time patch (the dart
            is still there; a neighbour landing nearby leaves them alone).
          ref_marked — those pixels still differ from the empty reference
            (occlusion fallback: something is covering them).
        Background around the dart can never fake a presence vote."""
        votes = like_votes = 0
        dbg = {}
        for c in self.hub.cameras:
            g = grays.get(c.index)
            patch = d.patches.get(c.index)
            if g is None or patch is None:
                continue
            pw, mask, x, y = patch
            h, w = g.shape
            if not (0 <= x < w and 0 <= y < h):
                continue
            rr = 16
            ys, xs = max(0, y - rr), max(0, x - rr)
            cw = g[ys:y + rr, xs:x + rr].astype(np.int16)
            if cw.shape != pw.shape:
                continue
            mcount = int(mask.sum())
            bar = max(6, int(0.35 * mcount))
            dw = cw - pw.astype(np.int16)
            bg = dw[~mask]   # exposure offset from the unchanged background px
            dw = np.abs(dw - (int(np.median(bg)) if bg.size else int(np.median(dw))))
            like = int(((dw > dth) & mask).sum()) < bar
            ref_marked = False
            det = self.detectors[c.index]
            if det._empty_gray is not None and c.index in ref_off:
                ew = det._empty_gray[ys:y + rr, xs:x + rr].astype(np.int16)
                if ew.shape == cw.shape:
                    de = np.abs(cw - ew - ref_off[c.index])
                    ref_marked = int(((de > dth) & mask).sum()) >= bar
            if like:
                like_votes += 1
            if like or ref_marked:
                votes += 1
            dbg[c.index] = {"mask": mcount, "like": like, "ref": ref_marked}
        return votes, like_votes, dbg

    def _committed_darts_gone(self, all_cleared: bool = False) -> bool:
        """Takeout check by the ACTUAL committed darts rather than the whole board:
        is each committed dart still on the board? A dart counts as still-present
        only if 2+ cameras vote so (mirrors the 2-camera commit rule), where a vote
        is "the spot still looks like this dart's own commit-time patch" OR "the
        spot still differs from the empty reference". If every committed dart gets
        fewer than 2 votes, they were pulled -> takeout. Darts with no verifiable
        evidence can't block takeout (backboard-parallax deadlock fix)."""
        if not self._darts:
            return False
        now = time.time()
        if all(d.bounced for d in self._darts):
            # only fallen darts remain — nothing physical to take out. A full
            # turn of them still auto-clears so the 3-dart cap can't wedge.
            return len(self._darts) >= 3 and now - self._last_commit > 4.0
        dth, grays, ref_off = self._presence_ctx()
        blocked = False
        debug = {}
        saw_like = False   # [experiment: fastTakeout] any patched dart still matches its shaft
        n_eval = 0
        for di, d in enumerate(self._darts):
            if (getattr(d, "off_board", False)
                    and now - self._last_hand < float(os.environ.get("WD_OFFBOARD_HAND_S", "8.0"))
                    and self._last_hand > d.t_land + 0.5):
                # ^ ORDER matters, not just recency (live 2026-07-22 18:50:13,
                # caught on recording): a REAL M-dart thrown <8s AFTER a pull
                # also matched the plain recency test, so it never held, and the
                # takeout gate (hand recent) wiped it the instant it committed —
                # "threw a dart, nothing shows". A mark being PULLED has the hand
                # arrive AFTER it landed (_last_hand > t_land); a fresh throw
                # lands AFTER the hand left (_last_hand < t_land) and must hold.
                # WEDGE FIX (reference hand-driven takeout): an off-board M scores
                # 0 and its surround blob (bounce mark / scuff) can persist
                # forever. During NORMAL play it holds like any dart (so a real
                # stuck miss isn't cleared early — that unconditional skip cost
                # the archive -23). But once a HAND is pulling, that mark must
                # NOT block the pull — the hand event, not the static blob,
                # decides the board is clearing. This is what un-wedges takeout.
                debug[di] = {"hit": d.hit.name, "off_board": True}
                continue
            if d.bounced:
                debug[di] = {"hit": d.hit.name, "bounced": True}
                continue
            votes, like_votes, dbg_cams = self._presence_votes(d, dth, grays, ref_off)
            if d.patches:
                n_eval += 1
                if like_votes >= 1:
                    saw_like = True
            # sample this dart's evidence for the phantom-vs-real time-series
            d.ev_hist.append((self._tick_n, votes, like_votes, len(d.patches)))
            if len(d.ev_hist) > 200:
                del d.ev_hist[:-200]
            # SUSPICION TIMER: when a dart stops looking like its own evidence on
            # every camera, only the reference votes keep it "present" — and the
            # reference may be poisoned (it can contain the dart itself, in which
            # case an empty spot reads as "changed" forever, wedging takeout).
            # Patch evidence dead everywhere for 12 s of stillness -> the dart no
            # longer blocks. A real occluded dart re-matches as soon as the
            # occlusion clears; a pulled dart never does. A dart that captured NO
            # usable evidence at commit blocks only through this same 12 s grace.
            if like_votes == 0:
                if d.suspect_since is None:
                    d.suspect_since = now
            else:
                d.suspect_since = None
            # BOUNCE-OUT: evidence died on every camera moments after this dart
            # landed, and no hand has been near the board — it fell out, it was
            # not pulled. Hold takeout briefly while deciding (a fall must never
            # read as a pull), then score it as a Miss like the reference board does.
            if (d.patches and votes == 0 and like_votes == 0
                    and now - d.t_commit < 5.0 and now - self._last_hand > 2.0):
                if d.suspect_since is not None and now - d.suspect_since > 0.8:
                    d.bounced = True
                    old = d.hit.name
                    d.hit = geo.Hit(d.hit.number, 0, f"M{d.hit.number}", "Outside", 0)
                    self.event = "Bounce out"
                    self._log("bounce-out", was=old, now=d.hit.name)
                    debug[di] = {"hit": d.hit.name, "bounced": True}
                else:
                    blocked = True
                    debug[di] = {"hit": d.hit.name, "votes": votes, "like": like_votes,
                                 "evidence": len(d.patches), "holds": True,
                                 "bounce_pending": True, "cams": dbg_cams}
                continue
            expired = d.suspect_since is not None and now - d.suspect_since > 12.0
            if not d.patches:
                # nothing can verify a no-evidence dart, so it holds through the
                # grace — EXCEPT when every camera reads the whole board as
                # empty vs the clean reference: then it is certainly gone (live:
                # an S15 with zero patches held takeout 12 s past the pull even
                # though the board was visibly bare)
                holds = not expired and not all_cleared
            else:
                # a dart only ever asked for as many votes as it has evidence
                # cams: demanding 2 votes from a 1-cam dart would read it as
                # "gone" on every tick and wipe live rounds via a spurious takeout
                holds = votes >= min(2, len(d.patches)) and not expired
            if holds:
                blocked = True
            debug[di] = {"hit": d.hit.name, "votes": votes, "like": like_votes,
                         "evidence": len(d.patches), "holds": holds, "cams": dbg_cams}
        # FAST TAKEOUT (default on; WD_FASTTAKEOUT=0 to disable): force takeout once
        # no patched dart matches its own shaft anywhere (like=0 board-wide) for
        # >2.5s with the hand gone — resets promptly on a pull. User-validated live.
        if os.environ.get("WD_FASTTAKEOUT", "1") == "1":
            if n_eval and not saw_like:
                self._like_dead_since = self._like_dead_since or now
            else:
                self._like_dead_since = None
            if (blocked and self._like_dead_since
                    and now - self._like_dead_since > 2.5 and now - self._last_hand > 1.0):
                self._log("takeout-like-dead", secs=round(now - self._like_dead_since, 1))
                blocked = False
        else:
            self._like_dead_since = None
        self._gone_debug = debug
        # log why takeout is held — once per distinct reason, not per tick
        if blocked:
            sig = tuple(sorted((str(v.get("hit")), bool(v.get("holds")), v.get("votes"), v.get("like"))
                               for v in debug.values()))
            if sig != self._last_block_sig:
                self._last_block_sig = sig
                self._log("hold", darts={str(k): {kk: vv for kk, vv in v.items() if kk != "cams"}
                                         for k, v in debug.items()})
        else:
            self._last_block_sig = None
        return not blocked     # no committed dart verifiably present any more -> pulled

    def _line_tip(self, pts: list[tuple], ref: tuple[float, float],
                  extra_lines: dict | None = None,
                  guard: float | None = None) -> tuple[float, float] | None:
        """Barrel-line intersection tip estimate (the reference board fusion model):
        each camera's shaft line maps through its homography to a board-plane
        line THROUGH the tip, so pairwise intersections of different cameras'
        lines localize the tip independently of the per-camera tip pixels.
        Gates: intersection angle >= 5 deg (near-parallel lines explode small
        pixel noise — the reference board 0.16.0 uses the same bar) and the intersection
        must land within WD_LINEGUARD mm of the point-fusion estimate (a bad
        line fit must never move a dart to another segment). Median of the
        surviving intersections, or None."""
        by_cam: dict[int, tuple] = {}
        for p in pts:
            if len(p) >= 5 and p[4] is not None and p[0] not in by_cam:
                by_cam[p[0]] = p[4]
        if extra_lines:
            # shaft-vote ballots from occluded-tip cameras (line only, no point)
            for c, ln in extra_lines.items():
                by_cam.setdefault(c, ln)
        if len(by_cam) < 2:
            return None
        guard = float(os.environ.get("WD_LINEGUARD", "12")) if guard is None else guard
        lines = []
        for (p1, p2) in by_cam.values():
            dx, dy = p2[0] - p1[0], p2[1] - p1[1]
            n = math.hypot(dx, dy)
            if n < 1e-6:
                continue
            lines.append((p1[0], p1[1], dx / n, dy / n))
        ix, iy = [], []
        for i in range(len(lines)):
            for j in range(i + 1, len(lines)):
                x1, y1, dx1, dy1 = lines[i]
                x2, y2, dx2, dy2 = lines[j]
                cross = dx1 * dy2 - dy1 * dx2
                # |cross| = sin(angle between unit dirs); 5 deg -> 0.087
                if abs(cross) < 0.087:
                    continue
                t = ((x2 - x1) * dy2 - (y2 - y1) * dx2) / cross
                px, py = x1 + t * dx1, y1 + t * dy1
                if math.hypot(px - ref[0], py - ref[1]) <= guard:
                    ix.append(px); iy.append(py)
        if not ix:
            return None
        return _median(ix), _median(iy)

    def _line_tip2(self, pts: list[tuple], base: tuple[float, float],
                   extra_lines: dict | None = None,
                   guard: float | None = None) -> tuple[float, float] | None:
        """Joint weighted least-squares line fusion (WD_LINEFUSE2): one 2x2
        solve for the point minimizing sum_i w_i*dist_perp(p, line_i)^2
        + lam*|p - base|^2 over ALL cameras' barrel lines at once. Unlike the
        pairwise intersections in _line_tip, near-parallel lines are FINE here:
        steep darts in the top sectors (20/5) map to near-radial board lines on
        every camera, so every pair failed the 5 deg gate exactly where the
        tip-occlusion bias is worst — jointly the lines still nail the
        perpendicular direction and the Tikhonov pull toward the point-fusion
        result supplies the rest. Each line enters via its unit normal n:
        A = sum w n n^T + lam*I, b = sum w (n.a) n + lam*base (a on line)."""
        by_cam: dict[int, tuple] = {}
        for p in pts:
            if len(p) >= 5 and p[4] is not None and p[0] not in by_cam:
                by_cam[p[0]] = p[4]
        extra_cams = set()
        if extra_lines:
            for c, ln in extra_lines.items():
                if c not in by_cam:
                    by_cam[c] = ln
                    extra_cams.add(c)
        if len(by_cam) < 2:
            return None
        lines = []
        for c, (p1, p2) in by_cam.items():
            dx, dy = p2[0] - p1[0], p2[1] - p1[1]
            ln = math.hypot(dx, dy)
            if ln < 1e-6:
                continue
            # a=(x,y), unit normal, mm length, is-shaft-vote
            lines.append((p1[0], p1[1], -dy / ln, dx / ln, ln, c in extra_cams))
        if len(lines) < 2:
            return None
        # Endpoints are the image shaft axis at +-80 px mapped to board mm, so
        # the mapped length is a local mm-per-px proxy: a LONGER line = a
        # coarser/more oblique view = more mm of perpendicular error per px of
        # fit noise -> inverse-variance weights, clamped so no camera is muted.
        # Shaft-vote lines are fitted in the NORMALIZED crop (~constant mapped
        # length), so their length is NOT an obliqueness proxy — exclude them
        # from lmin and pin their weight to the floor.
        real_lens = [l[4] for l in lines if not l[5]]
        lmin = min(real_lens) if real_lens else min(l[4] for l in lines)
        # lam ~ (line perp noise / point-fusion noise)^2: ~1mm lines vs a ~3mm
        # ("a few mm^2") prior -> 0.1; small enough that 2+ spread lines own
        # their constrained direction, big enough to hold the unconstrained one.
        lam = float(os.environ.get("WD_LF2_LAMBDA", "0.1"))
        axx = ayy = lam
        axy = 0.0
        bx, by = lam * base[0], lam * base[1]
        for x0, y0, nx, ny, ln, is_extra in lines:
            w = 0.2 if is_extra else max(0.2, min(1.0, (lmin / ln) ** 2))
            c = nx * x0 + ny * y0          # n . a  (line offset from origin)
            axx += w * nx * nx; axy += w * nx * ny; ayy += w * ny * ny
            bx += w * c * nx; by += w * c * ny
        det = axx * ayy - axy * axy
        if det < 1e-9:                     # lam*I makes A PD; pure numeric guard
            return None
        px = (bx * ayy - by * axy) / det
        py = (by * axx - bx * axy) / det
        # same spirit as WD_LINEGUARD: a bad joint fit must never move a dart
        # far enough to reach another segment
        g = float(os.environ.get("WD_LINEGUARD", "12")) if guard is None else guard
        if math.hypot(px - base[0], py - base[1]) > g:
            return None
        return px, py

    def _score_vote2(self, pts: list[tuple], fused: tuple[float, float]) -> tuple[float, float]:
        """Hardened score vote (WD_SCOREVOTE2). Differs from WD_SCOREVOTE in
        two ways: it runs AFTER the line refinement (so a line-corrected radius
        can argue back instead of being overruled sight unseen), and a camera
        only votes when its own estimate clears the nearest ring boundary by a
        margin — a voter 0.1mm past a wire is noise, not evidence, and on steep
        darts the per-cam radial errors are CORRELATED (all read inward), so an
        unfiltered majority is confidently wrong exactly where it matters."""
        by_cam: dict[int, list] = {}
        for p in pts:
            by_cam.setdefault(p[0], []).append((p[1], p[2]))
        if len(by_cam) < 2:
            return fused
        margin = float(os.environ.get("WD_SV2_MARGIN", "1.0"))
        rings = (geo.R_INNER_BULL, geo.R_OUTER_BULL, geo.R_TRIPLE_IN,
                 geo.R_TRIPLE_OUT, geo.R_DOUBLE_IN, geo.R_DOUBLE_OUT)
        names: dict[str, list] = {}
        for v in by_cam.values():
            x = sum(a for a, _ in v) / len(v)
            y = sum(b for _, b in v) / len(v)
            r = math.hypot(x, y)
            if min(abs(r - rb) for rb in rings) < margin:
                continue                   # too close to a ring line to be evidence
            names.setdefault(geo.score_at(x, y).name, []).append((x, y))
        if not names:
            return fused
        maj = max(names.items(), key=lambda kv: len(kv[1]))
        if len(maj[1]) >= 2 and geo.score_at(*fused).name != maj[0]:
            mx = sum(x for x, _ in maj[1]) / len(maj[1])
            my = sum(y for _, y in maj[1]) / len(maj[1])
            return mx, my
        return fused

    def _fuse_pts(self, pts: list[tuple], extra_lines: dict | None = None) -> tuple[float, float]:
        """Fuse (cam, x_mm, y_mm, tip_uv[, line]) estimates according to
        FUSE_MODE, then refine with the barrel lines: joint WLS solve when
        WD_LINEFUSE2=1, else pairwise intersection + polar blend (WD_LINEFUSE,
        default on). WD_SCOREVOTE2=1 swaps the pre-refinement majority vote for
        a hardened post-refinement one. Falls back to the robust component-wise
        median whenever the weighted path lacks inputs or fails."""
        base = self._fuse_pts_base(pts)
        # DEFAULT ON (2026-07-17): gate 432/467 (92.505%) + 128 perfect rounds
        # — both records; the unhardened vote gated 431/127.
        sv2 = os.environ.get("WD_SCOREVOTE2", "1") == "1"
        # SCORE-LEVEL MAJORITY VOTE (user-proposed): score each camera's own
        # position estimate; if >=2 cameras agree on a segment and the fused
        # position lands in a different one, side with the camera majority
        # (use the agreeing cameras' mean position). WD_SCOREVOTE2 replaces
        # this with the hardened post-refinement vote below.
        if not sv2 and os.environ.get("WD_SCOREVOTE", "1") == "1":
            by_cam: dict[int, list] = {}
            for p in pts:
                by_cam.setdefault(p[0], []).append((p[1], p[2]))
            if len(by_cam) >= 2:
                cams_pos = {c: (sum(x for x, _ in v) / len(v), sum(y for _, y in v) / len(v))
                            for c, v in by_cam.items()}
                names: dict[str, list] = {}
                for c, (x, y) in cams_pos.items():
                    names.setdefault(geo.score_at(x, y).name, []).append((x, y))
                maj = max(names.items(), key=lambda kv: len(kv[1]))
                if len(maj[1]) >= 2 and geo.score_at(*base).name != maj[0]:
                    mx = sum(x for x, _ in maj[1]) / len(maj[1])
                    my = sum(y for _, y in maj[1]) / len(maj[1])
                    base = (mx, my)
        fused = base
        r_b0 = math.hypot(base[0], base[1])
        # EDGE ELECTION (WD_EDGE_ELECTION, reference Election parity): out at the
        # double ring, a steep dart pointing UP has its CNN tip pixel ride up the
        # shaft on some cameras (outward), so the per-camera POINTS disagree
        # radially (measured live: same dart 163mm on one cam, 182mm on another)
        # and their median lands past 170mm -> a real double reads off-board M.
        # The barrel LINE is immune to along-shaft bias (the true tip is on every
        # camera's board-plane line, so the intersection pins it regardless of
        # where each tip pixel sat). Make the line the PRIMARY radius for r>EDGE_R,
        # with a released guard (bias exceeds the 12mm default) and the joint WLS
        # fallback for near-radial top darts the 5deg pairwise gate rejects.
        # Radius from the line, angle from the points (never crosses a wire).
        if (os.environ.get("WD_EDGE_ELECTION", "0") == "1"
                and r_b0 > float(os.environ.get("WD_EDGE_R", "150"))):
            eg = float(os.environ.get("WD_EDGE_GUARD", "24"))
            li = self._line_tip(pts, base, extra_lines, guard=eg)
            if li is None:
                li = self._line_tip2(pts, base, extra_lines, guard=eg)
            if li is not None and r_b0 > 1e-6:
                r_li = math.hypot(li[0], li[1])
                fused = (base[0] * r_li / r_b0, base[1] * r_li / r_b0)
            if sv2:
                fused = self._score_vote2(pts, fused)
            return fused
        lf2 = os.environ.get("WD_LINEFUSE2", "0")
        if lf2 == "full":
            # joint solve replaces the pairwise + polar path entirely — it IS
            # the radial refinement, near-parallel-safe (see _line_tip2).
            # Gate 430 vs 431: replacing the (+7-proven) polar blend loses a
            # hair on the archive, so "full" is kept for experiments only.
            li = self._line_tip2(pts, base, extra_lines)
            if li is not None:
                fused = li
        elif os.environ.get("WD_LINEFUSE", "1") == "1":
            li = self._line_tip(pts, base, extra_lines)
            if li is not None:
                # POLAR blend: the line intersection is precise RADIALLY (the
                # shaft runs ~radially, so the intersection nails the distance
                # from the bull — the T/S/D ring calls) but noisy TANGENTIALLY
                # (angular line error swings it across sector wires). Take the
                # radius from the lines, the sector angle from the points.
                # Measured: raw line positions fixed 7 ring rounds but broke 7
                # sector rounds; the polar split keeps only the win.
                r_li = math.hypot(li[0], li[1])
                r_b = math.hypot(base[0], base[1])
                if r_b > 1e-6:
                    fused = (base[0] * r_li / r_b, base[1] * r_li / r_b)
            elif lf2 == "1":
                # HYBRID: the pairwise path found NO valid intersection — for
                # near-radial (top-sector) darts every pair fails the 5 deg
                # gate and the tip-occlusion bias goes uncorrected. Only THEN
                # let the joint near-parallel-safe solve refine (polar split:
                # radius from the lines, angle from the points — same reasoning
                # as the pairwise blend above).
                lj = self._line_tip2(pts, base, extra_lines)
                if lj is not None:
                    r_lj = math.hypot(lj[0], lj[1])
                    r_b = math.hypot(base[0], base[1])
                    if r_b > 1e-6:
                        fused = (base[0] * r_lj / r_b, base[1] * r_lj / r_b)
        if sv2:
            fused = self._score_vote2(pts, fused)
        return fused

    def _fuse_pts_base(self, pts: list[tuple]) -> tuple[float, float]:
        if FUSE_MODE == "rank" and len({p[0] for p in pts}) >= 2:
            # RANK-WEIGHT fusion (user-proposed): rank cameras by how big they
            # see this spot (local px-per-mm from the homography Jacobian =
            # "closest camera") and blend with fixed weights — 3 cams 50/30/20,
            # 2 cams 65/35, 1 cam 100%.
            try:
                by_cam: dict[int, list[tuple]] = {}
                for cam, x, y, uv, *_ in pts:
                    by_cam.setdefault(cam, []).append((x, y, uv))
                ests = []
                for cam, ps in by_cam.items():
                    xs = sum(p[0] for p in ps) / len(ps)
                    ys = sum(p[1] for p in ps) / len(ps)
                    uvs = [p[2] for p in ps if p[2] is not None]
                    if not uvs:
                        raise ValueError("no uv")
                    u = sum(a for a, _ in uvs) / len(uvs)
                    v = sum(b for _, b in uvs) / len(uvs)
                    # _H is already the image->board direction (same as the wls
                    # path below); a dead `if False` inv(H) A/B leftover removed
                    J = _homography_jacobian(self.store.cfg.calibrations[cam]._H, u, v)
                    if J is None:
                        raise ValueError("degenerate")
                    # J = d(board mm)/d(image px); SMALL norm = many px per mm = close
                    scale = float(np.sqrt((J * J).sum() / 2.0))
                    ests.append((scale, xs, ys))
                ests.sort(key=lambda e: e[0])          # closest (finest) first
                W = {1: [1.0], 2: [0.65, 0.35], 3: [0.5, 0.3, 0.2]}[min(3, len(ests))]
                ests = ests[:len(W)]
                fx = sum(w * e[1] for w, e in zip(W, ests))
                fy = sum(w * e[2] for w, e in zip(W, ests))
                return fx, fy
            except Exception:
                pass
        if FUSE_MODE in ("wls", "trim") and len({p[0] for p in pts}) >= 2:
            try:
                by_cam: dict[int, list[tuple]] = {}
                for cam, x, y, uv, *_ in pts:
                    by_cam.setdefault(cam, []).append((x, y, uv))
                ests = []
                for cam, ps in by_cam.items():
                    xs = sum(p[0] for p in ps) / len(ps)
                    ys = sum(p[1] for p in ps) / len(ps)
                    uvs = [p[2] for p in ps if p[2] is not None]
                    if not uvs:
                        raise ValueError("no uv")
                    uv = (sum(u for u, _ in uvs) / len(uvs), sum(v for _, v in uvs) / len(uvs))
                    ests.append((cam, xs, ys, uv))
                if FUSE_MODE == "trim" and len(ests) >= 3:
                    # drop the camera farthest from the consensus
                    def spread(i):
                        return sum(math.hypot(ests[i][1] - e[1], ests[i][2] - e[2])
                                   for j, e in enumerate(ests) if j != i)
                    ests = sorted(ests, key=lambda e: spread(ests.index(e)))[:-1]
                Ws, b = [], np.zeros(2)
                for cam, x, y, (u, v) in ests:
                    calib = self.store.cfg.calibrations[cam]
                    H = calib._H
                    J = _homography_jacobian(H, u, v)
                    if J is None:      # degenerate projection — skip this camera
                        continue
                    W = np.linalg.inv(J @ J.T + np.eye(2) * 1e-9)
                    # TWIST-AWARE per-region camera power (user idea, made
                    # data-driven): the calibration self-check measured each
                    # camera's double-ring radial offset per 18deg sector —
                    # down-weight a camera exactly where its own fit is known
                    # to be off (live cam1: +0.7-1.8mm at 36-72deg produced
                    # the right-edge misreads). Weight ~ 1/(sigma^2+twist^2),
                    # sigma 0.35mm = a good camera's baseline. No profile
                    # (archive replays, old configs) -> weight 1: gate-neutral.
                    tw_prof = getattr(calib, "twist", None)
                    if tw_prof and len(tw_prof) == 20 and os.environ.get("WD_TWIST_W", "1") == "1":
                        ang = (math.degrees(math.atan2(y, x)) + 360.0) % 360.0
                        tw = abs(tw_prof[int(((ang + 9) % 360) // 18) % 20])
                        W = W * (0.35 ** 2 / (0.35 ** 2 + tw ** 2) if tw > 0 else 1.0)
                    Ws.append(W)
                    b += W @ np.array([x, y])
                if not Ws:
                    raise ValueError("no usable jacobians")
                r = np.linalg.inv(np.sum(Ws, axis=0)) @ b
                return float(r[0]), float(r[1])
            except Exception:
                pass
        return _fuse([(cam, x, y) for cam, x, y, *_ in pts])

    def _cluster(self, cands: list[DartCandidate], tol: float) -> list[dict]:
        """Greedy spatial clustering of candidates across cameras.

        The fused position is the component-wise MEDIAN of the per-camera estimates,
        not their mean. With 3 cameras, the median ignores the single worst view
        (a dart half-occluded by another dart, or seen at a steep oblique angle
        where small pixel error becomes large board error) instead of letting it
        drag the result across a ring/wire boundary. For 2 cameras the median is
        the midpoint (same as the mean). This is the cheap, no-retrain accuracy win
        for the boundary darts that cause most scoring errors.
        """
        clusters: list[dict] = []
        # RADIUS-ADAPTIVE tolerance (live 2026-07-22, recorded misses): at the
        # oblique 8/11 rim the per-camera SURROUND estimates scatter 21-108mm
        # (coarse wide-crop path + extrapolated homography), so real 2-3-cam
        # rim misses never fused at the fixed 18mm bar and expired silently —
        # the best recorded case failed by 3.3mm. Off-board scoring needs only
        # the SECTOR (18 deg at r=200 is ~63mm of arc), so widening fusion to
        # 40mm out there is score-safe. On-board pairs keep the tight bar.
        rim_tol = max(tol, float(os.environ.get("WD_RIM_AGREE_MM", "40.0")))
        for c in cands:
            uv = getattr(c, "tip_uv", None)
            ln = getattr(c, "line", None)
            sc = getattr(c, "area", 0.0)
            c_rim = math.hypot(c.x_mm, c.y_mm) > geo.R_DOUBLE_OUT * 1.02
            placed = False
            for cl in clusters:
                t = rim_tol if (c_rim and math.hypot(cl["x"], cl["y"])
                                > geo.R_DOUBLE_OUT * 1.02) else tol
                if math.hypot(cl["x"] - c.x_mm, cl["y"] - c.y_mm) <= t:
                    cl["pts"].append((c.cam, c.x_mm, c.y_mm, uv, ln))
                    cl["score"] = max(cl["score"], sc)
                    cl["x"], cl["y"] = self._fuse_pts(cl["pts"])
                    placed = True
                    break
            if not placed:
                clusters.append({"pts": [(c.cam, c.x_mm, c.y_mm, uv, ln)], "x": c.x_mm, "y": c.y_mm, "score": sc})
        for cl in clusters:
            cl["x"], cl["y"] = self._fuse_pts(cl["pts"])
            cl["cams"] = len({p[0] for p in cl["pts"]})
        return clusters

    # -- state out -------------------------------------------------------------
    def state_dict(self) -> dict:
        with self._lock:
            throws = []
            for i, d in enumerate(self._darts):
                throws.append({
                    "segment": d.hit.as_segment(),
                    "coords": geo.normalise(d.x_mm, d.y_mm),
                    "cams": d.cams,
                })
            return {
                "connected": self.hub.any_connected(),
                "running": self.running,
                "status": self.status,
                "event": self.event,
                "name": self.store.cfg.name or "WiseDarts Board",
                "motionState": self.motion_state(),
                "numThrows": len(self._darts),
                "throws": throws,
            }

    def _emit(self, force: bool = False) -> None:
        if self.on_change is None:
            return
        state = self.state_dict()
        sig = (state["status"], state["running"], state["connected"], state["numThrows"],
               tuple((t["segment"]["name"], round(t["coords"]["x"], 3), round(t["coords"]["y"], 3)) for t in state["throws"]))
        if not force and sig == self._last_emit_sig:
            return
        self._last_emit_sig = sig
        try:
            self.on_change(state)
        except Exception:
            pass
