"""
Per-camera dart detection — classic EVENT pipeline.

Architecture (mapped from the real the reference board engine's internals):

  * a ring buffer of recent still frames per camera;
  * when the scene starts CHANGING (frame-to-frame), freeze "Before" — the last
    still frame from the buffer, i.e. the board just before anything moved;
  * when the scene SETTLES again, take "After" and classify the frozen
    Before/After difference:
        dart-sized  -> a DART event: run the tip CNN on the frozen diff,
        hand-sized  -> a HAND event (a reach-in / takeout — no tips),
        tiny        -> noise, discard;
  * each dart is scored from its own frozen pair, so later motion — the next
    throw, the pull, a hand — can NEVER corrupt or delay it. This is what makes
    rapid fire, instant pulls and "stuck on motion" structurally impossible.

The tip model itself is unchanged (heatmap CNN via cv2.dnn, no torch at runtime).
"""

from __future__ import annotations

import math
import os
import threading
from collections import deque
from dataclasses import dataclass, field

import cv2
import numpy as np

from .calibration import Calibration
from . import geometry as geo
from . import tipnet

# Trained dart-tip detector (heatmap CNN). When present, it replaces the
# classic-CV tip heuristic — far more accurate (it learnt the actual tip from
# the reference board-labelled throws). Run via cv2.dnn, so no PyTorch at runtime.
_TIP_NET = None
_TIP_LOADED = False

# Force the classic-CV (no-CNN) detector even when a model is present.
_FORCE_CLASSIC = os.environ.get("WD_DETECT", "").lower() == "classic"

# Tip-CNN inference resolution. The UNet is fully convolutional, so with a
# dynamic-dims ONNX export the SAME weights can run on a finer board crop —
# the 160px crop is ~2.9 mm/px, the dominant noise source in wire calls.
TIP_INFER = int(os.environ.get("WD_TIP_SIZE", "0")) or 160

# Per-event classification trace (offline diagnosis of missed darts).
_EVT_DEBUG = bool(os.environ.get("WD_EVT_DEBUG"))

# Test-time flip-ensemble for the tip CNN (4x inference per dart event).
_TTA = os.environ.get("WD_TTA", "0") == "1"   # replay-gated: flips are
# out-of-distribution (darts always lean one way) — 91.5% vs 92.96%

# Noise gate for dart events, in 160-crop pixels. A twin landing partly BEHIND
# an existing dart leaves only a sliver of new pixels (measured: 62 px for a
# real S20 twin vs the old min_dart_area=80 bar -> classified noise, dart lost).
# The tip CNN's confidence threshold is the real arbiter; this bar only spares
# the CNN from pure flicker.
_DART_PX_BAR = int(os.environ.get("WD_MIN_DART", "0")) or None

# The scoring crop (tipnet.CROP_MARGIN) covers the physical board; this WIDE zone
# also covers the surround, so a dart that clips the board edge or misses onto the
# backboard still triggers an event and registers as a miss (the reference board reads those).
WIDE_MARGIN = 2.0

# BOARD-FACE MASK (reference BoardMask parity): the square crop's corners are
# off-board surround (~59% of the crop area at CROP_MARGIN=1.38) — a shadow,
# reflection or resting hand there used to inflate the hand-gate count (a real
# dart dropped as "hand") and stall the cleared re-baseline. The aggregate
# hand/cleared gates count inside the board polygon only; the dart_bar noise
# floor stays UNMASKED on purpose (a faint twin's off-board shaft pixels are
# real evidence of a dart-sized event, and 62px slivers live near that bar).
_BOARD_MASK = os.environ.get("WD_BOARD_MASK", "1") == "1"


def _tip_model_path() -> str:
    # WD_TIP_MODEL lets validation/eval point at a candidate model; the live
    # service uses the bundled one.
    return os.environ.get("WD_TIP_MODEL") or os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "tip_cnn.onnx")


_TIP_GEN = 0
_TIP_TLS = threading.local()


def _tip_net():
    # PER-THREAD net instances: cv2.dnn.Net is not thread-safe, and the
    # per-camera detects now run in a thread pool (WD_PAR_DETECT) — a shared
    # net corrupted its layer shapes under concurrent forward() (measured:
    # concat2_layer assertion in replay). Each pool thread lazily loads its
    # own copy; the generation counter lets reload_tip_net invalidate all.
    if getattr(_TIP_TLS, "gen", None) != _TIP_GEN:
        _TIP_TLS.gen = _TIP_GEN
        _TIP_TLS.net = None
        path = _tip_model_path()
        if os.path.exists(path):
            try:
                _TIP_TLS.net = cv2.dnn.readNetFromONNX(path)
            except cv2.error:
                _TIP_TLS.net = None
    return _TIP_TLS.net


def reload_tip_net() -> bool:
    """Invalidate every thread's cached net and load whatever tip_cnn.onnx is
    on disk now (used by the auto-retrainer to hot-swap with no restart)."""
    global _TIP_GEN
    _TIP_GEN += 1
    return _tip_net() is not None


def _skeletonize(binary: np.ndarray) -> np.ndarray:
    """1px-ish medial skeleton of a binary blob. Uses ximgproc's Zhang-Suen when
    the contrib module is present (cleaner), else a core-OpenCV morphological
    skeleton (iterative erode/open-subtract) that works on any build — including
    the Pi's headless OpenCV. Returns a uint8 mask of skeleton pixels."""
    if hasattr(cv2, "ximgproc"):
        try:
            return cv2.ximgproc.thinning(binary)
        except cv2.error:
            pass
    elem = cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))
    img = binary.copy()
    skel = np.zeros_like(img)
    for _ in range(64):                        # bounded; a dart window skeletonizes fast
        opened = cv2.morphologyEx(img, cv2.MORPH_OPEN, elem)
        skel = cv2.bitwise_or(skel, cv2.subtract(img, opened))
        img = cv2.erode(img, elem)
        if cv2.countNonZero(img) == 0:
            break
    return skel


@dataclass
class DartCandidate:
    cam: int
    x_mm: float
    y_mm: float
    area: float
    tip_uv: tuple[float, float]
    # board-space BARREL LINE through the tip: ((x1,y1),(x2,y2)) in mm, or None.
    # A homography maps the shaft's image line to a board-plane line that passes
    # exactly through the tip (the tip lies ON the plane), so intersecting two
    # cameras' lines localizes the tip independently of each camera's tip-pixel
    # estimate — the fusion model the reference board uses (line intersection + a 5 deg
    # degenerate-angle gate).
    line: tuple | None = None


@dataclass
class CamObservation:
    candidates: list[DartCandidate] = field(default_factory=list)
    motion: bool = False       # the scene is moving RIGHT NOW (frame-to-frame)
    changed_px: int = 0        # informational (vision UI)
    cleared: bool = False      # board ~ matches the empty reference (re-baseline only)
    hand_event: bool = False   # a hand-sized event just completed (reach-in / pull)
    event_done: bool = False   # ANY event completed this tick (dart/hand/noise)
    # LINE-ONLY shaft vote from a no-tip dart event (occluded tip): board-mm
    # ((x1,y1),(x2,y2)) through the unseen tip, or None. Engine-side Election.
    shaft_line: tuple | None = None
    # largest in-ring surround blob of an event that minted NO candidates
    # (x_mm, y_mm, px) — aims the engine's hint-rescue probe. None otherwise.
    reject_hint: tuple | None = None
    # BOUNCE-OUT: an event that PEAKED with a dart-sized blob then settled EMPTY
    # (dart hit and fell off). {peak, hits:[{hit,x,y,score}]} for the peak frame.
    bounce_diag: dict | None = None


class CameraDetector:
    """Event machine for one camera. detect() is called once per engine tick."""

    _bdump = 0   # diagnostic: bounce-frame dumps this process (self-capped)

    def __init__(self, cam_index: int, tuning):
        self.cam = cam_index
        self.tuning = tuning
        self._empty_gray: np.ndarray | None = None   # the empty board (takeout / ghost checks)
        self._ref_gray: np.ndarray | None = None     # last event's After (vision Movement tab only)
        self._buffer: deque[np.ndarray] = deque(maxlen=8)   # recent STILL frames
        self._state = "idle"                          # idle | changing
        self._before: np.ndarray | None = None        # frozen at change start
        self._srr_hint: tuple | None = None           # reject-hint (see _surround_misses)
        self._event_hand_ticks = 0                    # hand-sized motion ticks in this event
        self._peak_changed = 0.0                      # max subsampled change-vs-Before in this event
        self._peak_gray: np.ndarray | None = None     # the frame at that peak (bounce detection)
        # FAST-BOUNCE: keep the top-K most-changed frames of the event, not just
        # the single peak. A quick bounce is in-plane for less than one camera
        # frame, so its true impact frame can land on ANY tick (incl. the trigger
        # frame) — scoring the best few recovers bounces a single snapshot misses.
        self._peak_frames: list[tuple[int, np.ndarray]] = []
        self._bounce_diag: dict | None = None         # bounce-out diagnostic for this event
        self._settle = 0                              # settled ticks while changing
        self._changing_ticks = 0
        self._prev_small: np.ndarray | None = None    # last downscaled crop (frame-to-frame)
        self._last_gray: np.ndarray | None = None     # reused by engine takeout check
        self._last_params = None                      # reused by per-dart snapshots
        self._last_dc: np.ndarray | None = None       # last event diff (per-dart snapshots)
        self._last_before: np.ndarray | None = None   # last event's Before (arrival masks)
        # TURN REFERENCE: the settled board snapshotted the moment each dart
        # COMMITS — so the next throw's event diffs against a frame that already
        # contains every prior dart, and a re-detection of an existing dart shows
        # zero change (can't become a phantom). the reference board's per-throw model. None
        # at turn start (first dart diffs against the empty/pre-motion frame).
        self._turn_ref: np.ndarray | None = None
        # live diagnostics (surfaced in /api/health) — what the event machine did
        self.stats = {"dart_events": 0, "hand_events": 0, "noise_events": 0,
                      "cands": 0, "ghost_dropped": 0, "offboard_dropped": 0, "last_changed": 0}
        self._mask_cache: dict = {}      # (params,size) -> board-face crop mask
        # camera (re)open warmup: until this time the event machine stays idle so
        # the driver's exposure/gain re-hunt can't fire an event or freeze a
        # mid-ramp Before (reference StartupWaitFrames parity). Live-only: the
        # engine arms it on a watchdog reopen; replays never reopen a camera.
        self._warmup_until = 0.0

    def has_reference(self) -> bool:
        return self._empty_gray is not None

    def _prep(self, frame: np.ndarray) -> np.ndarray:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        k = max(1, self.tuning.blur_ksize | 1)  # force odd
        return cv2.GaussianBlur(gray, (k, k), 0)

    def set_reference(self, frame: np.ndarray) -> None:
        """Board is empty — reset the empty reference and the event machine."""
        g = self._prep(frame)
        self._empty_gray = g
        self._ref_gray = g
        self._buffer.clear()
        self._buffer.append(g)
        self._state = "idle"
        self._before = None
        self._settle = 0
        self._prev_small = None
        self._turn_ref = None

    def begin_warmup(self) -> None:
        """Camera just (re)opened: suppress the event machine briefly and drop
        the frame-to-frame history so the exposure/gain ramp is never read as
        motion (and never spans the discontinuity)."""
        import time as _time
        self._warmup_until = _time.time() + float(os.environ.get("WD_WARMUP_S", "0.5"))
        self._prev_small = None

    def _board_mask(self, calib: Calibration, params, size: int) -> np.ndarray | None:
        """Binary mask (1 = physical board face incl. number ring) in crop
        space. The board maps to an ellipse-ish polygon under perspective, so
        sample the board-edge circle through the calibration rather than
        drawing a circle. Cached per (params, size) — params only changes with
        recalibration."""
        key = (round(params[0], 1), round(params[1], 1), round(params[2], 1), size)
        m = self._mask_cache.get(key)
        if m is not None:
            return m
        if not calib.ready:
            return None
        pts = []
        R = geo.R_DOUBLE_OUT * geo.R_BOARD_FACTOR
        for a in np.linspace(0.0, 2.0 * math.pi, 48, endpoint=False):
            uv = calib.to_image(R * math.cos(a), R * math.sin(a))
            if uv is None:
                return None
            px, py = tipnet.board_to_crop(uv[0], uv[1], params, size=size)
            # reject a horizon/mirrored projection: a board-edge point past the
            # plane's horizon on a steep camera maps to a finite MIRRORED (or
            # overflowing) image point, which fillPoly folds into a bowtie/garbage
            # fill that the >5% sanity check below won't catch. The board face
            # sits INSIDE the crop, so any vertex far outside it is bogus — fall
            # back to unmasked (return None) rather than cache a wrong mask.
            if not (-size <= px <= 2 * size and -size <= py <= 2 * size):
                return None
            pts.append((px, py))
        m = np.zeros((size, size), np.uint8)
        cv2.fillPoly(m, [np.array(pts, np.int32)], 1)
        # sanity: a degenerate homography can collapse the polygon — fall back
        # to unmasked counting rather than gate on a sliver
        if int(m.sum()) < (size * size) // 20:
            return None
        if len(self._mask_cache) > 8:
            self._mask_cache.clear()
        self._mask_cache[key] = m
        return m

    def snap_turn_ref(self) -> None:
        """A dart just committed — freeze the current settled frame as the turn
        reference so the NEXT throw's event is diffed against a board that
        already contains this (and every prior) dart."""
        if self._last_gray is not None:
            self._turn_ref = self._last_gray

    def clear_turn_ref(self) -> None:
        """New turn / takeout — the next first dart diffs against the pre-motion
        frame again."""
        self._turn_ref = None

    def advance_reference(self, frame: np.ndarray) -> None:
        """Kept for compatibility (the event pipeline no longer needs it)."""
        self._ref_gray = self._prep(frame)

    # -- frame-to-frame motion (exposure/gain compensated) -----------------------
    def _moving_px(self, gray: np.ndarray, wide_params) -> int:
        s = max(1, self.tuning.motion_scale)
        cur = tipnet.crop(gray, wide_params)
        cur = cv2.resize(cur, (cur.shape[1] // s, cur.shape[0] // s))
        if self._prev_small is None and self._empty_gray is not None:
            # seed the frame-to-frame history from the empty reference so the very
            # first transition after a re-baseline still triggers an event (without
            # this there was a one-tick blind spot right after every takeout).
            ref = tipnet.crop(self._empty_gray, wide_params)
            self._prev_small = cv2.resize(ref, (ref.shape[1] // s, ref.shape[0] // s))
        moving = 0
        if self._prev_small is not None and self._prev_small.shape == cur.shape:
            # Remove a GLOBAL affine brightness change (gain*prev + offset): cheap
            # cameras hunt auto-exposure AND auto-gain between frames; the residual
            # keeps only genuine localised movement.
            p = self._prev_small.astype(np.float32)
            q = cur.astype(np.float32)
            pf = p.ravel()
            if pf.std() > 1.0:
                a, b = np.polyfit(pf, q.ravel(), 1)
            else:
                a, b = 1.0, 0.0
            d = q - (a * p + b)
            moving = int((np.abs(d) > self.tuning.motion_threshold).sum())
        self._prev_small = cur
        return moving

    # -- event pipeline (CNN) ----------------------------------------------------
    def _detect_cnn(self, frame: np.ndarray, calib: Calibration, net) -> CamObservation:
        gray = self._prep(frame)
        self._last_gray = gray
        params = tipnet.crop_params(calib._H)
        self._last_params = params

        wide_params = tipnet.crop_params(calib._H, margin=WIDE_MARGIN)
        moving_px = self._moving_px(gray, wide_params)
        small_size = max(1, ((tipnet.TIP_SIZE // max(1, self.tuning.motion_scale)) ** 2))
        # two thresholds on the same signal: a DART-sized flicker must trigger an
        # event (sensitive), while only a big blob counts as "hand moving" (status).
        trigger = moving_px >= self.tuning.trigger_px
        hand_moving = moving_px > self.tuning.settle_frac * small_size

        # lighting-robust "board is empty" (vs the EMPTY reference). The bar is
        # ABSOLUTE and below a single dart's footprint: an empty exposure-compensated
        # diff has a few stray px, one dart has hundreds — a fractional bar tied to
        # the (now wider) crop wrongly read a one-dart board as "cleared" and fired
        # takeouts that wiped freshly committed darts.
        cleared = False
        changed_info = 0
        if self._empty_gray is not None:
            sd = tipnet.crop(gray, params).astype(np.int16) - tipnet.crop(self._empty_gray, params).astype(np.int16)
            sd -= int(np.median(sd))
            nz = int((np.abs(sd) > self.tuning.diff_threshold).sum())
            changed_info = nz
            # DELIBERATELY UNMASKED. Masking the cleared count to the board face
            # makes a false "board empty" MORE likely — an oblique near-double
            # dart or a surround M-dart loses its off-face pixels and reads as
            # gone — and all_cleared then waives the takeout grace AND the hand
            # gate (engine), so a masked cleared could wipe a live turn and
            # poison the empty reference. The board mask helps only the HAND gate.
            cleared = nz < 3 * self.tuning.min_dart_area

        cands: list[DartCandidate] = []
        hand_event = False
        event_done = False
        shaft_line = None

        if self._state == "idle":
            if trigger and self._buffer:
                # change just began — freeze Before: the last STILL frame
                self._before = self._buffer[-1]
                self._state = "changing"
                self._settle = 0
                self._changing_ticks = 0
                self._event_hand_ticks = 0
                self._peak_changed = 0.0
                self._peak_gray = None
                self._peak_frames = []
                # the frame that TRIGGERED the event is a peak candidate too — for
                # a fast bounce it is often the impact frame itself, and the
                # changing-branch loop below only scores from the NEXT tick on.
                if self._before is not None and self._before.shape == gray.shape:
                    dd0 = cv2.absdiff(gray[::3, ::3], self._before[::3, ::3])
                    self._note_peak(int((dd0 > self.tuning.diff_threshold).sum()), gray)
            else:
                self._buffer.append(gray)
        else:  # changing
            self._changing_ticks += 1
            # BOUNCE PEAK: remember the frame most changed from Before during
            # this event — a bounced dart is most-present here, an instant
            # before it fell out. Cheap subsampled count; the CNN only runs on
            # this frame later IF the event settles EMPTY (a bounce candidate).
            if self._before is not None and self._before.shape == gray.shape:
                dd = cv2.absdiff(gray[::3, ::3], self._before[::3, ::3])
                self._note_peak(int((dd > self.tuning.diff_threshold).sum()), gray)
            if hand_moving:
                # count hand-SIZED motion ticks inside this event window. A
                # dart's flight streaks 1 tick at most; an arm/pull is many.
                self._event_hand_ticks += 1
            if trigger:
                self._settle = 0
                if self._changing_ticks > 240:   # ~1 min of nonstop motion — bail out
                    self._state = "idle"
                    self._before = None
                    self._buffer.append(gray)
            else:
                self._settle += 1
                if self._settle >= self.tuning.settle_frames * getattr(self, "_tscale", 1):
                    # EVENT COMPLETE. HAND-TAINT RULE (the reference board's
                    # model, user demand 2026-07-22: "it should NEVER add darts
                    # when a hand is in the frame"): if a hand was part of this
                    # event's change window, the Before/After diff is a mix of
                    # removals, arm shadow and re-exposed board — scoring it
                    # mints phantom/removal candidates (live: M11s committed
                    # the moment a pull began). Classify the WHOLE event as a
                    # hand event: no candidates, arms the engine's hand hold.
                    if (self._event_hand_ticks >= 2
                            and os.environ.get("WD_HAND_TAINT", "1") == "1"):
                        self.stats["hand_events"] += 1
                        cands, hand_event, shaft_line = [], True, None
                    else:
                        # classify the frozen Before/After difference
                        cands, hand_event, shaft_line = self._finish_event(gray, calib, params, wide_params, net)
                    event_done = True
                    self._state = "idle"
                    self._before = None
                    self._buffer.append(gray)

        return CamObservation(cands, hand_moving or (self._state == "changing" and self._changing_ticks > 2),
                              changed_info, cleared, hand_event, event_done, shaft_line,
                              reject_hint=(self._srr_hint
                                           if event_done and not cands and not hand_event
                                           else None),
                              bounce_diag=(self._bounce_diag if event_done else None))

    def _note_peak(self, changed: int, gray: np.ndarray, k: int = 3):
        """Track the top-K most-changed frames of the current event (fast-bounce
        impact recovery). Keeps the single strongest as _peak_gray/_peak_changed
        (diagnostic + dump), plus the best K frames for the bounce-out CNN pass."""
        if changed > self._peak_changed:
            self._peak_changed = float(changed)
            self._peak_gray = gray
        self._peak_frames.append((changed, gray))
        if len(self._peak_frames) > k:
            mi = min(range(len(self._peak_frames)), key=lambda i: self._peak_frames[i][0])
            self._peak_frames.pop(mi)

    def probe_tip(self, u: float, v: float, calib: Calibration, radius_px: int = 7, min_score: float = 0.2):
        """GUIDED SECOND LOOK: is there a dart tip near image position (u, v)
        right now? Runs the tip CNN on the CUMULATIVE diff (current frame vs the
        empty reference — exactly the training distribution, which was labelled
        on level-vs-level0 diffs with every dart present) and searches only a
        small window at the projected spot. Used by the engine to rescue a dart
        that only one camera's event machine caught: this camera may never have
        fired an event, but the dart is still standing in its view.
        Returns a DartCandidate or None."""
        net = None if _FORCE_CLASSIC else _tip_net()
        if net is None or self._empty_gray is None or self._last_gray is None:
            return None
        params = self._last_params
        if params is None or not calib.ready:
            return None
        dc = tipnet.crop(cv2.absdiff(self._last_gray, self._empty_gray), params, size=TIP_INFER)
        x = (dc.astype(np.float32) / 255.0)[None, None]
        net.setInput(x)
        hm = net.forward()[0, 0]
        px, py = tipnet.board_to_crop(u, v, params, size=TIP_INFER)
        h, w = hm.shape
        x0, x1 = max(0, int(px) - radius_px), min(w, int(px) + radius_px + 1)
        y0, y1 = max(0, int(py) - radius_px), min(h, int(py) + radius_px + 1)
        if x1 <= x0 or y1 <= y0:
            return None
        win = hm[y0:y1, x0:x1]
        score = float(win.max())
        # confirmation bar, not detection bar: another camera already vouches
        if score < min_score:
            return None
        iy, ix = np.unravel_index(int(np.argmax(win)), win.shape)
        pxp, pyp = x0 + ix, y0 + iy
        r = 4
        xx0, xx1 = max(0, pxp - r), min(w, pxp + r + 1)
        yy0, yy1 = max(0, pyp - r), min(h, pyp + r + 1)
        patch = hm[yy0:yy1, xx0:xx1]
        sm = patch.sum()
        if sm > 0:
            ys, xs = np.mgrid[yy0:yy1, xx0:xx1]
            cxp = float((xs * patch).sum() / sm)
            cyp = float((ys * patch).sum() / sm)
        else:
            cxp, cyp = float(pxp), float(pyp)
        uu, vv = tipnet.crop_to_image(cxp, cyp, params, size=TIP_INFER)
        b = calib.to_board(uu, vv)
        if b is None or math.hypot(*b) > geo.R_DOUBLE_OUT * geo.R_BOARD_FACTOR:
            return None
        self.stats["rescued"] = self.stats.get("rescued", 0) + 1
        return DartCandidate(self.cam, b[0], b[1], score, (uu, vv))

    def _finish_event(self, after: np.ndarray, calib: Calibration, params, wide_params, net):
        """The scene settled: score the frozen Before/After pair.
        Returns (candidates, hand_event, shaft_line)."""
        self._srr_hint = None   # reject-hint from _surround_misses (this event only)
        self._bounce_diag = None
        if self._before is None:
            return [], False, None
        # Diff the new dart against the TURN REFERENCE (the board as it was after
        # the last dart committed) when available — this is what stops an already-
        # committed dart re-appearing as a "new" arrival when the buffered Before
        # predates it (the 2-3s double-registration). Falls back to the frozen
        # pre-motion Before for the turn's first dart. Same shape required.
        ref = self._before
        if (getattr(self, "_turn_ref_on", True) and self._turn_ref is not None
                and self._turn_ref.shape == after.shape):
            ref = self._turn_ref
        # kept past the event so the engine can build each committed dart's
        # arrival mask (which pixels the dart actually changed) at commit time
        self._last_before = ref
        dc = tipnet.crop(cv2.absdiff(after, ref), params, size=TIP_INFER)
        self._last_dc = dc
        area = dc.shape[0] * dc.shape[1]
        # absolute pixel-count thresholds were tuned at the 160px crop; scale by
        # crop area so higher-resolution inference keeps identical semantics
        scale2 = (TIP_INFER / tipnet.TIP_SIZE) ** 2
        changed = int((dc > self.tuning.diff_threshold).sum())
        self.stats["last_changed"] = changed
        # HAND gate on the BOARD FACE only: the square crop's corners are
        # surround, and a shadow/arm there inflated `changed` past garbage_frac
        # — a real dart landing in the same event was thrown away as "hand".
        # The dart_bar noise floor below deliberately keeps the UNMASKED count
        # (off-board shaft pixels are real evidence for faint twins).
        hand_changed, hand_area = changed, area
        if _BOARD_MASK:
            bm = self._board_mask(calib, params, dc.shape[0])
            if bm is not None:
                hand_changed = int(((dc > self.tuning.diff_threshold) & (bm > 0)).sum())
                # FLOOR the denominator: garbage_frac was tuned against the FULL
                # crop, but on an oblique camera the board ellipse is only
                # ~0.4-0.55 of the crop — an unfloored bm.sum() halves the bar
                # and trips the hand gate ~2x early, discarding a dart's ballot
                # on a dart+shadow co-event. Keep the effective pixel bar in the
                # regime garbage_frac expects regardless of camera obliqueness.
                hand_area = max(int(bm.sum()), int(0.6 * area))
        if _EVT_DEBUG:
            print(f"EVT cam{self.cam} changed={changed} dart_bar={self.tuning.min_dart_area * scale2:.0f}"
                  f" hand_bar={self.tuning.garbage_frac * hand_area:.0f} hand_changed={hand_changed}")
        if hand_changed >= self.tuning.garbage_frac * hand_area:
            self.stats["hand_events"] += 1
            return [], True, None                  # hand-sized: a reach-in / pull
        # NOTE: intentionally NOT tuning.min_dart_area — that value still governs
        # the whole-board "cleared" re-baseline bar; the event gate is only
        # flicker protection. Lowered 40 -> 25 (2026-07-22): a dart at the extreme
        # outer edge (double ring) seen at an oblique angle paints a razor-thin
        # sliver — round_0635's D2 was 38px on cam1, dropped as flicker, so only
        # 1 camera saw it and it never committed. 25 lets that sliver through and
        # the downstream gates (2-cam agreement + ghost + radius) still reject
        # real flicker: full 467 archive 40->432, 30->433, 25->434, phantoms
        # unchanged at 2. The line-Election/shaft-vote can't help here — the
        # sliver dies at THIS gate before any fusion runs.
        dart_bar = _DART_PX_BAR if _DART_PX_BAR is not None else 25
        if changed <= dart_bar * scale2:
            # nothing stuck ON the board — but a dart may have clipped the board
            # edge or missed onto the surround (the reference board reads those as M-darts).
            miss = self._surround_misses(after, calib, wide_params)
            if miss:
                self.stats["dart_events"] += 1
                self.stats["cands"] += len(miss)
                return miss, False, None
            # BOUNCE-OUT diagnostic: nothing stuck AND no surround mark, yet a
            # dart-sized blob PEAKED mid-event then vanished (After == empty) —
            # the dart hit and bounced off. Detect it on the PEAK frame vs the
            # same ref, so we can later score it as a Miss (0). Diagnostic-only
            # for now (no candidate returned): the engine logs bounce_diag.
            peak_bar = float(os.environ.get("WD_BOUNCE_PEAK", "8"))
            # FAST-BOUNCE: score the best few impact frames of the event, not just
            # the single peak. A quick bounce's true impact frame can be any of the
            # top-K (incl. the trigger frame); the tip that any one of them yields
            # is what we keep. The CNN only runs here — on an empty-settle event —
            # so a handful of extra forward passes cost nothing in the hot path.
            cand_frames = [(pc, pg) for (pc, pg) in self._peak_frames
                           if pg is not None and pc >= peak_bar and pg.shape == ref.shape]
            if cand_frames:
                best_pchanged = 0
                raw_hits = []   # (bx, by, score, name) pooled across candidate frames
                for (pc, pg) in cand_frames:
                    pdc = tipnet.crop(cv2.absdiff(pg, ref), params, size=TIP_INFER)
                    pchanged = int((pdc > self.tuning.diff_threshold).sum())
                    best_pchanged = max(best_pchanged, pchanged)
                    if net is None or pchanged <= dart_bar * scale2:
                        continue
                    xin = pdc.astype(np.float32) / 255.0
                    net.setInput(xin[None, None])
                    hm = net.forward()[0, 0]
                    for px, py, sc in tipnet.decode_peaks(
                            hm, min_dist=max(5, round(5 * TIP_INFER / tipnet.TIP_SIZE))):
                        u, v = tipnet.crop_to_image(px, py, params, size=TIP_INFER)
                        b = calib.to_board(u, v)
                        if b is None or math.hypot(*b) > geo.R_DOUBLE_OUT * geo.R_BOARD_FACTOR:
                            continue
                        sh = geo.score_at(b[0], b[1])
                        raw_hits.append((float(b[0]), float(b[1]), float(sc),
                                         sh.name if sh else "?"))
                # the same tip caught across 2-3 frames -> keep only the max score
                hits = []
                for (bx, by, sc, nm) in sorted(raw_hits, key=lambda h: h[2], reverse=True):
                    if any(math.hypot(bx - h["x"], by - h["y"]) < 15.0 for h in hits):
                        continue
                    hits.append({"hit": nm, "x": round(bx, 1), "y": round(by, 1),
                                 "score": round(sc, 2)})
                self._bounce_diag = {"peak_sub": int(self._peak_changed),
                                     "peak_changed": best_pchanged, "hits": hits}
                # DIAGNOSTIC (WD_BOUNCE_DUMP): save the impact frame + ref + diff so
                # the bounce-out detection can be tuned against real frames offline.
                if os.environ.get("WD_BOUNCE_DUMP") and CameraDetector._bdump < 240:
                    try:
                        import time as _t
                        _dbg = os.path.join(os.path.dirname(os.path.dirname(
                            os.path.abspath(__file__))), "bounce_debug")
                        os.makedirs(_dbg, exist_ok=True)
                        _b = os.path.join(_dbg, "%d_cam%d" % (int(_t.time() * 2), self.cam))
                        cv2.imwrite(_b + "_peak.png", self._peak_gray)
                        cv2.imwrite(_b + "_ref.png", ref)
                        cv2.imwrite(_b + "_diff.png", cv2.absdiff(self._peak_gray, ref))
                        with open(_b + ".txt", "w") as _f:
                            _f.write("cam=%d peak_sub=%d peak_changed=%d hits=%s\n" % (
                                self.cam, int(self._peak_changed), best_pchanged, hits))
                        CameraDetector._bdump += 1
                    except Exception:
                        pass
            self.stats["noise_events"] += 1
            return [], False, None                 # flicker / nothing stuck
        self.stats["dart_events"] += 1
        self._ref_gray = after                     # vision Movement tab baseline
        g0 = self.stats["ghost_dropped"]           # shaft-vote removal veto

        # DART event -> tip CNN on the frozen diff. Test-time ensemble: the net
        # is not flip-invariant, so running it on the 4 flip variants and
        # averaging the un-flipped heatmaps cancels a good share of its
        # per-inference placement noise — the millimetres that decide wire
        # calls. Runs once per dart event, so 4x inference is affordable.
        cands: list[DartCandidate] = []
        x = dc.astype(np.float32) / 255.0
        acc = None
        for fl in (None, 1, 0, -1) if _TTA else (None,):
            xi = x if fl is None else cv2.flip(x, fl)
            net.setInput(xi[None, None])
            h = net.forward()[0, 0]
            if fl is not None:
                h = cv2.flip(h, fl)
            acc = h if acc is None else acc + h
        hm = acc / (4.0 if _TTA else 1.0)
        for px, py, score in tipnet.decode_peaks(
                hm, min_dist=max(5, round(5 * TIP_INFER / tipnet.TIP_SIZE))):
            u, v = tipnet.crop_to_image(px, py, params, size=TIP_INFER)
            b = calib.to_board(u, v)
            # anywhere on the PHYSICAL board (incl. the number ring -> "M20")
            if b is None or math.hypot(*b) > geo.R_DOUBLE_OUT * geo.R_BOARD_FACTOR:
                self.stats["offboard_dropped"] += 1
                continue
            # REMOVAL-GHOST filter, DIRECTIONAL: a pulled dart lights the diff at
            # its old spot exactly like a new dart landing. Discriminate by which
            # side of the event held the dart: a LANDING dart differs from the
            # empty board more in After than in Before; a PULLED dart the opposite.
            # The relative test keeps FAINT real darts (an absolute bar used to eat
            # a thin tip seen by an oblique camera — a real dart lost its 3rd vote).
            if self._empty_gray is not None and self._before is not None:
                xi, yi = int(u), int(v)
                gh, gw_ = after.shape
                if 0 <= xi < gw_ and 0 <= yi < gh:
                    # TIGHT window (a stacked twin dart 5-10 mm away must not
                    # dominate the comparison) + decisive MARGIN (ties keep the
                    # dart; only a clear was-there-before wins drops it).
                    r = 7
                    ys, ye = max(0, yi - r), yi + r
                    xs, xe = max(0, xi - r), xi + r
                    ew = self._empty_gray[ys:ye, xs:xe].astype(np.int16)
                    if ew.size:
                        thr = self.tuning.diff_threshold * 0.75
                        # exposure offset from the WHOLE frame, not the window:
                        # a twin landing beside an existing dart makes the 14x14
                        # window dart-dominated, so the window median IS the dart
                        # and subtracting it zeroed wa — a genuinely landed 2nd
                        # dart read as a removal ghost and was dropped (the
                        # "missed the 2nd dart right next to it" bug).
                        off_a = int(np.median(after[::8, ::8].astype(np.int16)
                                              - self._empty_gray[::8, ::8].astype(np.int16)))
                        off_b = int(np.median(self._before[::8, ::8].astype(np.int16)
                                              - self._empty_gray[::8, ::8].astype(np.int16)))
                        aw = after[ys:ye, xs:xe].astype(np.int16) - ew - off_a
                        wa = int((np.abs(aw) > thr).sum())      # after vs empty
                        bw = self._before[ys:ye, xs:xe].astype(np.int16) - ew - off_b
                        wb = int((np.abs(bw) > thr).sum())      # before vs empty
                        if wb > wa + max(4, int(0.3 * wa)):     # clearly MORE dart-like before -> removal
                            self.stats["ghost_dropped"] += 1
                            if _EVT_DEBUG:
                                print(f"EVT cam{self.cam} GHOST-DROP ({b[0]:.1f},{b[1]:.1f}) wa={wa} wb={wb}")
                            continue
            if _EVT_DEBUG:
                print(f"EVT cam{self.cam} cand ({b[0]:.1f},{b[1]:.1f}) score={score:.2f}")
            cands.append(DartCandidate(self.cam, b[0], b[1], score, (u, v),
                                       line=self._barrel_line(after, ref, u, v, calib)))
        # an on-board dart event can coincide with an edge/surround hit (bounce-out
        # partner, wild 2nd dart) — check the surround ring too
        cands.extend(self._surround_misses(after, calib, wide_params, onboard=cands))
        # SHAFT-VOTE (reference Election parity, WD_SHAFTVOTE): mint a LINE-ONLY
        # ballot ONLY for a genuine occluded-tip arrival — a dart-sized event
        # that produced NO candidate of any kind (no CNN tip, no surround miss)
        # AND did not ghost-drop a departing dart. Another dart hides this tip
        # but the shaft still painted the diff, so the tip lies ON a board line;
        # intersecting it with the cameras that did see the tip localizes it
        # (their fusion model). A pulled/knocked-out dart paints the same
        # elongated blob, so the removal-ghost signal is a hard veto here.
        shaft_line = None
        ghosted = self.stats["ghost_dropped"] > g0
        if (not cands and not ghosted
                and os.environ.get("WD_SHAFTVOTE", "0") == "1"):
            shaft_line = self._event_shaft_line(dc, after, params, calib)
        self.stats["cands"] += len(cands)
        # WIDE-HAND fallback (live 2026-07-22 manual-reset wedge): a QUICK pull
        # of a SURROUND dart paints its arm mostly BELOW/OUTSIDE the board
        # ellipse, so the masked hand gate above never fires and the engine's
        # _last_hand stays stale — the pulled dart's dent then holds takeout
        # (the t_land ordering release needs a hand seen AFTER landing). When
        # the event minted NOTHING on the board yet the UNMASKED change is
        # hand-sized, that IS an arm working at the surround — report it as a
        # hand event. Dart events (candidates minted) are untouched, so the
        # old dart+shadow-discarded-as-hand bug cannot return.
        if not cands and changed >= self.tuning.garbage_frac * area:
            self.stats["hand_events"] += 1
            return [], True, None
        return cands, False, shaft_line

    def _event_shaft_line(self, dc: np.ndarray, after: np.ndarray, params,
                          calib: Calibration) -> tuple | None:
        """Board-space axis line of the event diff's dominant blob for the
        line-only shaft vote, plus its bull-ward TIP end. Guards: dart-sized
        elongated component (>=3:1); the tip end must sit ON the physical board
        face (not a surround/arm sliver); and an ARRIVAL check at the tip end
        (more dart-like vs empty in After than in Before) — a removal/knock-out
        blob fails it. Returns ((p1,p2),(ex,ey)) board mm or None. The engine
        adds an end-near-cluster + perpendicular guard on top."""
        mask = (dc > self.tuning.diff_threshold).astype(np.uint8)
        n, lab, stats_, _ = cv2.connectedComponentsWithStats(
            cv2.dilate(mask, np.ones((3, 3), np.uint8)))
        if n < 2:
            return None
        areas = stats_[1:, cv2.CC_STAT_AREA]
        lid = 1 + int(np.argmax(areas))
        scale2 = (dc.shape[0] / tipnet.TIP_SIZE) ** 2
        if int(areas[lid - 1]) < 30 * scale2 or int(areas[lid - 1]) > 2500 * scale2:
            return None
        ys, xs = np.nonzero(lab == lid)
        pts = np.column_stack([xs, ys]).astype(np.float32)
        cov = np.cov(pts.T)
        evals = np.linalg.eigvalsh(cov)
        if evals[1] < 9 * max(evals[0], 1e-6):     # need >=3:1 elongation
            return None
        vx, vy, cx0, cy0 = cv2.fitLine(pts, cv2.DIST_HUBER, 0, 0.01, 0.01).flatten()
        S = dc.shape[0]
        # the axis ENDS must be REAL blob pixels (project onto the axis, take the
        # extremes) — extrapolating ±S/3 puts the "tip" in empty space, so the
        # arrival check would sample nothing and pass a removal blob.
        proj = (pts - np.array([cx0, cy0], np.float32)) @ np.array([vx, vy], np.float32)
        ends = []                                  # (board_x, board_y, img_u, img_v)
        for ec in (pts[int(proj.argmin())], pts[int(proj.argmax())]):
            u, v = tipnet.crop_to_image(float(ec[0]), float(ec[1]), params, size=S)
            b = calib.to_board(u, v)
            if b is None:
                return None
            ends.append((float(b[0]), float(b[1]), u, v))
        ends.sort(key=lambda e: math.hypot(e[0], e[1]))
        tip_b, far_b = ends[0], ends[1]            # tip = bull-ward end (real pixel)
        # the tip end must be ON the physical board face — a shaft aimed across
        # the surround (arm, off-board sliver) has its near end off the board
        if math.hypot(tip_b[0], tip_b[1]) > geo.R_DOUBLE_OUT * geo.R_BOARD_FACTOR:
            return None
        # ARRIVAL check at the tip end (same directional test the tip candidates
        # use): a dart is THERE now only if the spot is more changed-vs-empty in
        # After than in Before. A pulled/knocked-out dart is the reverse -> drop.
        if self._empty_gray is not None and self._before is not None:
            xi, yi = int(tip_b[2]), int(tip_b[3])
            gh, gw_ = after.shape
            if 0 <= xi < gw_ and 0 <= yi < gh:
                r = 7
                y0, y1 = max(0, yi - r), yi + r
                x0, x1 = max(0, xi - r), xi + r
                ew = self._empty_gray[y0:y1, x0:x1].astype(np.int16)
                if ew.size:
                    thr = self.tuning.diff_threshold * 0.75
                    off_a = int(np.median(after[::8, ::8].astype(np.int16)
                                          - self._empty_gray[::8, ::8].astype(np.int16)))
                    off_b = int(np.median(self._before[::8, ::8].astype(np.int16)
                                          - self._empty_gray[::8, ::8].astype(np.int16)))
                    wa = int((np.abs(after[y0:y1, x0:x1].astype(np.int16) - ew - off_a) > thr).sum())
                    wb = int((np.abs(self._before[y0:y1, x0:x1].astype(np.int16) - ew - off_b) > thr).sum())
                    if wb > wa:                    # more dart-like BEFORE -> removal
                        return None
        return ((tip_b[0], tip_b[1]), (far_b[0], far_b[1])), (tip_b[0], tip_b[1])

    def _barrel_line(self, after: np.ndarray, ref: np.ndarray, u: float, v: float,
                     calib: Calibration) -> tuple | None:
        """Fit the dart's shaft/flight axis in the FULL-RESOLUTION event diff
        around the tip and map it to a board-space line. Homographies map lines
        to lines and the tip is on the board plane, so the mapped line passes
        through the tip — two cameras' lines intersect AT the tip (the reference board'
        fusion model). Full-res matters: the 160px crop quantizes the axis
        angle, and a fraction of a degree is millimetres at the tip. Returns
        ((x1,y1),(x2,y2)) board mm or None (blob too small/round to orient)."""
        if ref is None or after.shape != ref.shape:
            return None
        H, W = after.shape
        xi, yi = int(u), int(v)
        R = int(os.environ.get("WD_LINE_WIN", "110"))  # px window: tip + shaft at 720p
        x0, x1 = max(0, xi - R), min(W, xi + R)
        y0, y1 = max(0, yi - R), min(H, yi + R)
        if x1 - x0 < 30 or y1 - y0 < 30:
            return None
        d = cv2.absdiff(after[y0:y1, x0:x1], ref[y0:y1, x0:x1])
        mask = (d > self.tuning.diff_threshold).astype(np.uint8)
        n_lab, lab = cv2.connectedComponents(cv2.dilate(mask, np.ones((3, 3), np.uint8)))
        lx, ly = xi - x0, yi - y0
        lid = lab[ly, lx] if (0 <= lx < lab.shape[1] and 0 <= ly < lab.shape[0]) else 0
        if lid == 0:
            win = lab[max(0, ly - 4):ly + 5, max(0, lx - 4):lx + 5]
            vals = win[win > 0]
            if not vals.size:
                return None
            lid = int(np.bincount(vals).argmax())
        ys, xs = np.nonzero(lab == lid)
        if len(xs) < 60:                      # too few px to orient reliably
            return None
        pts = np.column_stack([xs, ys]).astype(np.float32)
        cov = np.cov(pts.T)
        evals = np.linalg.eigvalsh(cov)
        if evals[1] < 9 * max(evals[0], 1e-6):   # need >=3:1 elongation
            return None
        # THINNING (WD_THIN_LINE, reference parity): the raw blob includes the
        # fan-shaped FLIGHT, whose off-axis mass tilts fitLine's axis (a fraction
        # of a degree is mm at the tip). Skeletonize to the medial spine first so
        # the fit sees collinear centreline points. Uses ximgproc's Zhang-Suen
        # when present, else a CORE-OpenCV morphological skeleton (works on the
        # Pi / any build, no contrib module needed).
        if os.environ.get("WD_THIN_LINE", "0") == "1":
            try:
                comp = np.zeros(mask.shape, np.uint8)
                comp[ys, xs] = 255
                sk = _skeletonize(comp)
                sy, sx = np.nonzero(sk)
                if len(sx) >= 15:
                    pts = np.column_stack([sx, sy]).astype(np.float32)
            except cv2.error:
                pass
        vx, vy, cx0, cy0 = cv2.fitLine(pts, cv2.DIST_HUBER, 0, 0.01, 0.01).flatten()
        out = []
        for t in (-80.0, 80.0):
            b = calib.to_board(x0 + cx0 + t * vx, y0 + cy0 + t * vy)
            if b is None:
                return None
            out.append((float(b[0]), float(b[1])))
        return (out[0], out[1])

    # wide-crop analysis resolution: 224 px over 2R keeps a dart's thin shaft
    # ~2-3 px wide (at 160 px it eroded to nothing and contourArea was ~0 for a
    # thin sliver — real M-darts in the black surround were never seen).
    _WIDE_SIZE = 224

    def _surround_misses(self, after: np.ndarray, calib: Calibration, wide_params, onboard=()):
        """Dart-sized blobs OUTSIDE the scoring area (board edge / surround) in the
        frozen event diff -> miss candidates (M<sector>). A miss needs no mm
        precision — only the sector angle. Filters by component PIXEL COUNT (a thin
        dart's contour AREA is near zero) and skips erosion (it eats thin shafts)."""
        if self._before is None or not calib.ready:
            return []
        W = self._WIDE_SIZE
        wd = tipnet.crop(cv2.absdiff(after, self._before), wide_params, size=W)
        _, mask = cv2.threshold(wd, self.tuning.diff_threshold, 255, cv2.THRESH_BINARY)
        n, labels, stats, _ = cv2.connectedComponentsWithStats(mask.astype(np.uint8))
        out = []
        # MIN-NEW-PIXELS floor (reference DetectionMinNewPixels parity): the old
        # 8px floor let a faint scuff/reflection/glint mint a phantom off-board M.
        # A real miss-dart's shaft fragment in the wide crop is dozens of px. Raise
        # the floor (env WD_SURROUND_MIN_NEW) so a sub-dart speckle can't commit.
        min_new = int(os.environ.get("WD_SURROUND_MIN_NEW", "8"))
        for i in range(1, n):
            px_count = int(stats[i, cv2.CC_STAT_AREA])
            # dart-sized in wide-crop pixels: >= floor (thin shaft fragment) and
            # well under a hand/arm blob
            if px_count < min_new or px_count > 2500:
                continue
            ys, xs = np.nonzero(labels == i)
            pts = np.column_stack([xs, ys]).astype(np.float64)
            mean = pts.mean(axis=0)
            # REJECT HINT (live 2026-07-22, the M11 triple: darts landed and
            # every camera's event ended empty): before the shape gates below
            # can reject this blob, remember the largest in-ring position. If
            # the whole event mints nothing, the engine points the live tip
            # CNN at the hint on all cameras (hint-rescue) — the blob only
            # AIMS the probe, the CNN decides.
            hu_, hv_ = tipnet.crop_to_image(float(mean[0]), float(mean[1]), wide_params, size=W)
            hb_ = calib.to_board(hu_, hv_)
            if hb_ is not None:
                hr_ = math.hypot(*hb_)
                if (geo.R_DOUBLE_OUT * 1.02 < hr_ < geo.R_DOUBLE_OUT * 1.6
                        and (self._srr_hint is None or px_count > self._srr_hint[2])):
                    self._srr_hint = (float(hb_[0]), float(hb_[1]), px_count)
            centred = pts - mean
            try:
                _, sv, vt = np.linalg.svd(centred, full_matrices=False)
            except np.linalg.LinAlgError:
                continue
            # a dart (shaft + flight) is ELONGATED; a round shadow/reflection blob
            # is not — this keeps the permissive pixel floor from admitting noise
            if sv[0] < 2.0 * max(sv[1], 1e-6):
                continue
            proj = centred @ vt[0]
            best = None
            ends_b = []
            for end in (pts[int(proj.argmin())], pts[int(proj.argmax())]):
                u, v = tipnet.crop_to_image(float(end[0]), float(end[1]), wide_params, size=W)
                b = calib.to_board(u, v)
                if b is None:
                    continue
                ends_b.append((float(b[0]), float(b[1])))
                r = math.hypot(*b)
                if best is None or r < best[0]:
                    best = (r, b, (u, v))            # tip = the end closer to the bull
            if best is None:
                continue
            # BARREL LINE for the Election (the reference board's fusion): the
            # blob's axis mapped to a board-plane line. At the oblique rim the
            # per-camera POINT estimates scatter cm-scale (extrapolated
            # homography), but the along-shaft component of that error lies ON
            # this line — two cameras' lines intersect at the true tip, so
            # _fuse_pts' polar blend recovers the position the points can't.
            line_b = tuple(ends_b) if len(ends_b) == 2 and ends_b[0] != ends_b[1] else None
            r, b, uv = best
            # only the ring between the scoring area and the wide edge: on-board
            # darts are the CNN's job; beyond ~1.9R is off the surround entirely
            if not (geo.R_DOUBLE_OUT * 1.02 < r < geo.R_DOUBLE_OUT * 1.6):
                continue
            # an ON-BOARD dart's flight/shaft often pokes past the board edge —
            # a surround blob at the SAME ANGLE as an on-board candidate is that
            # dart's tail, not a separate miss
            ang = math.atan2(b[1], b[0])
            if any(abs((math.atan2(oc.y_mm, oc.x_mm) - ang + math.pi) % (2 * math.pi) - math.pi) < 0.20
                   for oc in onboard):
                continue
            # ghost filter (directional, same as on-board): pulled surround dart ->
            # the spot was MORE dart-like in Before than in After -> removal, drop
            if self._empty_gray is not None and self._before is not None:
                xi, yi = int(uv[0]), int(uv[1])
                gh, gw_ = after.shape
                if 0 <= xi < gw_ and 0 <= yi < gh:
                    rr = 7
                    ys, ye = max(0, yi - rr), yi + rr
                    xs, xe = max(0, xi - rr), xi + rr
                    ew = self._empty_gray[ys:ye, xs:xe].astype(np.int16)
                    if ew.size:
                        thr = self.tuning.diff_threshold * 0.75
                        # exposure offset from the WHOLE frame, not the window —
                        # same bug as the on-board ghost filter had (a dart
                        # dominating its own 14x14 window IS the window median,
                        # so subtracting it zeroed the evidence and a real
                        # miss/edge dart was dropped as a removal ghost)
                        off_a = int(np.median(after[::8, ::8].astype(np.int16)
                                              - self._empty_gray[::8, ::8].astype(np.int16)))
                        off_b = int(np.median(self._before[::8, ::8].astype(np.int16)
                                              - self._empty_gray[::8, ::8].astype(np.int16)))
                        aw = after[ys:ye, xs:xe].astype(np.int16) - ew - off_a
                        wa = int((np.abs(aw) > thr).sum())
                        bw = self._before[ys:ye, xs:xe].astype(np.int16) - ew - off_b
                        wb = int((np.abs(bw) > thr).sum())
                        if wb > wa + max(4, int(0.3 * wa)):
                            self.stats["ghost_dropped"] += 1
                            continue
            out.append(DartCandidate(self.cam, float(b[0]), float(b[1]), float(px_count),
                                     (float(uv[0]), float(uv[1])), line=line_b))
        return out

    # -- entry point ---------------------------------------------------------------
    def detect(self, frame: np.ndarray, calib: Calibration) -> CamObservation:
        if self._empty_gray is None:
            self.set_reference(frame)
            return CamObservation()

        if self._warmup_until:
            import time as _time
            if _time.time() < self._warmup_until:
                # (re)open warmup — gates BOTH pipelines (the classic fallback
                # runs when the tip net fails to load, e.g. the OpenCV 4.13 ONNX
                # incident, exactly when a watchdog reopen is likely). Stay idle
                # through the exposure/gain ramp and — crucially — do NOT publish
                # _last_gray: the engine's presence / bounce-out / takeout checks
                # read it directly, and a mid-ramp frame reads a standing dart as
                # "gone" (a whole-hub reopen would flip a real dart to Bounce-out
                # on every camera at once). Keep the last pre-reopen frame.
                g = self._prep(frame)
                self._state = "idle"
                self._before = None
                self._settle = 0
                self._prev_small = None
                self._buffer.append(g)
                return CamObservation()
            self._warmup_until = 0.0

        net = None if _FORCE_CLASSIC else _tip_net()
        if net is not None and calib.ready:
            return self._detect_cnn(frame, calib, net)
        return self._detect_classic(frame, calib)

    # -- classic-CV fallback (no model): reference-diff contours -------------------
    def _detect_classic(self, frame: np.ndarray, calib: Calibration) -> CamObservation:
        gray = self._prep(frame)
        self._last_gray = gray
        ref = self._ref_gray if self._ref_gray is not None else self._empty_gray
        # exposure-robust diff: cancel a global brightness shift
        sd = gray.astype(np.int16) - ref.astype(np.int16)
        sd -= int(np.median(sd))
        diff = np.abs(sd).astype(np.uint8)
        _, mask = cv2.threshold(diff, self.tuning.diff_threshold, 255, cv2.THRESH_BINARY)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        mask = cv2.dilate(mask, np.ones((3, 3), np.uint8), iterations=1)
        changed = int(cv2.countNonZero(mask))

        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        candidates: list[DartCandidate] = []
        motion = False
        for c in contours:
            area = cv2.contourArea(c)
            if area < self.tuning.min_dart_area:
                continue
            if calib.ready:
                m = cv2.moments(c)
                if m["m00"] != 0:
                    b = calib.to_board(m["m10"] / m["m00"], m["m01"] / m["m00"])
                    if b is not None and math.hypot(*b) > geo.R_DOUBLE_OUT * geo.R_BOARD_FACTOR:
                        continue
            if area > self.tuning.max_dart_area:
                motion = True  # too big AND on the board -> a hand reaching in
                continue
            cand = self._candidate_from_contour(c, area, calib)
            if cand is not None:
                candidates.append(cand)
        return CamObservation(candidates, motion, changed)

    def _candidate_from_contour(self, contour, area: float, calib: Calibration) -> DartCandidate | None:
        if not calib.ready:
            return None
        pts = contour.reshape(-1, 2).astype(np.float64)
        if len(pts) < 2:
            return None
        # principal axis of the blob -> its two ends; the dart tip is the end that
        # sits further *into* the board (smaller board-space radius), since the
        # shaft/flight extends outward over the rim.
        mean = pts.mean(axis=0)
        centred = pts - mean
        try:
            _, _, vt = np.linalg.svd(centred, full_matrices=False)
        except np.linalg.LinAlgError:
            return None
        axis = vt[0]
        proj = centred @ axis
        end_a = pts[int(proj.argmin())]
        end_b = pts[int(proj.argmax())]

        ba = calib.to_board(float(end_a[0]), float(end_a[1]))
        bb = calib.to_board(float(end_b[0]), float(end_b[1]))
        choices = []
        if ba is not None:
            choices.append((math.hypot(*ba), ba, end_a))
        if bb is not None:
            choices.append((math.hypot(*bb), bb, end_b))
        if not choices:
            return None
        choices.sort(key=lambda t: t[0])
        radius, (x_mm, y_mm), tip = choices[0]
        if radius > geo.R_DOUBLE_OUT * geo.R_BOARD_FACTOR:
            return None
        return DartCandidate(self.cam, x_mm, y_mm, area, (float(tip[0]), float(tip[1])))
